﻿namespace QLCHVBDQ
{
    partial class fThemDVT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxTenDVT = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.textTenLDV = new System.Windows.Forms.Label();
            this.textBoxMaDVT = new System.Windows.Forms.TextBox();
            this.line1 = new System.Windows.Forms.Label();
            this.textMaLDV = new System.Windows.Forms.Label();
            this.textThemLDV = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxTenDVT
            // 
            this.textBoxTenDVT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenDVT.Location = new System.Drawing.Point(590, 280);
            this.textBoxTenDVT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenDVT.Name = "textBoxTenDVT";
            this.textBoxTenDVT.Size = new System.Drawing.Size(352, 43);
            this.textBoxTenDVT.TabIndex = 94;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(677, 480);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(265, 95);
            this.btnThem.TabIndex = 86;
            this.btnThem.Text = "Thêm DVT";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // textTenLDV
            // 
            this.textTenLDV.AutoSize = true;
            this.textTenLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenLDV.ForeColor = System.Drawing.Color.Black;
            this.textTenLDV.Location = new System.Drawing.Point(584, 177);
            this.textTenLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenLDV.Name = "textTenLDV";
            this.textTenLDV.Size = new System.Drawing.Size(215, 32);
            this.textTenLDV.TabIndex = 89;
            this.textTenLDV.Text = "Tên đơn vị tính";
            this.textTenLDV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMaDVT
            // 
            this.textBoxMaDVT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaDVT.Location = new System.Drawing.Point(78, 280);
            this.textBoxMaDVT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxMaDVT.Name = "textBoxMaDVT";
            this.textBoxMaDVT.Size = new System.Drawing.Size(364, 43);
            this.textBoxMaDVT.TabIndex = 83;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 138);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1079, 2);
            this.line1.TabIndex = 87;
            // 
            // textMaLDV
            // 
            this.textMaLDV.AutoSize = true;
            this.textMaLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaLDV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textMaLDV.Location = new System.Drawing.Point(72, 177);
            this.textMaLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaLDV.Name = "textMaLDV";
            this.textMaLDV.Size = new System.Drawing.Size(204, 32);
            this.textMaLDV.TabIndex = 84;
            this.textMaLDV.Text = "Mã đơn vị tính";
            // 
            // textThemLDV
            // 
            this.textThemLDV.AutoSize = true;
            this.textThemLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemLDV.Location = new System.Drawing.Point(68, 49);
            this.textThemLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemLDV.Name = "textThemLDV";
            this.textThemLDV.Size = new System.Drawing.Size(394, 55);
            this.textThemLDV.TabIndex = 82;
            this.textThemLDV.Text = "Thêm đơn vị tính";
            // 
            // fThemDVT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 632);
            this.Controls.Add(this.textBoxTenDVT);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.textTenLDV);
            this.Controls.Add(this.textBoxMaDVT);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textMaLDV);
            this.Controls.Add(this.textThemLDV);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemDVT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm đơn vị tính";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTenDVT;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label textTenLDV;
        private System.Windows.Forms.TextBox textBoxMaDVT;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textMaLDV;
        private System.Windows.Forms.Label textThemLDV;
    }
}