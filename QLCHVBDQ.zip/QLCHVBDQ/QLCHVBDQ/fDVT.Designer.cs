﻿namespace QLCHVBDQ
{
    partial class fDVT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.DashboardTrangChu = new System.Windows.Forms.Panel();
            this.btnDVT = new System.Windows.Forms.Button();
            this.btnTLTT = new System.Windows.Forms.Button();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.btnLoaiNhanVien = new System.Windows.Forms.Button();
            this.btnCaiDat = new System.Windows.Forms.Button();
            this.btnKhachHang = new System.Windows.Forms.Button();
            this.textDsPDV = new System.Windows.Forms.Label();
            this.dtgvDVT = new System.Windows.Forms.DataGridView();
            this.panelUserName = new System.Windows.Forms.Panel();
            this.textUserName = new System.Windows.Forms.Label();
            this.TrangChu = new System.Windows.Forms.Panel();
            this.btnDeletes = new System.Windows.Forms.PictureBox();
            this.btnThemDVT = new System.Windows.Forms.Button();
            this.DashboardTrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDVT)).BeginInit();
            this.panelUserName.SuspendLayout();
            this.TrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeletes)).BeginInit();
            this.SuspendLayout();
            // 
            // DashboardTrangChu
            // 
            this.DashboardTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DashboardTrangChu.Controls.Add(this.btnDVT);
            this.DashboardTrangChu.Controls.Add(this.btnTLTT);
            this.DashboardTrangChu.Controls.Add(this.picBoxLogo);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiNhanVien);
            this.DashboardTrangChu.Controls.Add(this.btnCaiDat);
            this.DashboardTrangChu.Controls.Add(this.btnKhachHang);
            this.DashboardTrangChu.Location = new System.Drawing.Point(0, 0);
            this.DashboardTrangChu.Name = "DashboardTrangChu";
            this.DashboardTrangChu.Size = new System.Drawing.Size(127, 666);
            this.DashboardTrangChu.TabIndex = 0;
            // 
            // btnDVT
            // 
            this.btnDVT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnDVT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDVT.FlatAppearance.BorderSize = 0;
            this.btnDVT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDVT.ForeColor = System.Drawing.Color.White;
            this.btnDVT.Location = new System.Drawing.Point(0, 307);
            this.btnDVT.Name = "btnDVT";
            this.btnDVT.Size = new System.Drawing.Size(127, 44);
            this.btnDVT.TabIndex = 18;
            this.btnDVT.Text = "Đơn vị tính";
            this.btnDVT.UseVisualStyleBackColor = false;
            // 
            // btnTLTT
            // 
            this.btnTLTT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTLTT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTLTT.FlatAppearance.BorderSize = 0;
            this.btnTLTT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTLTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTLTT.ForeColor = System.Drawing.Color.White;
            this.btnTLTT.Location = new System.Drawing.Point(0, 263);
            this.btnTLTT.Name = "btnTLTT";
            this.btnTLTT.Size = new System.Drawing.Size(127, 44);
            this.btnTLTT.TabIndex = 17;
            this.btnTLTT.Text = "Tham số";
            this.btnTLTT.UseVisualStyleBackColor = false;
            this.btnTLTT.Click += new System.EventHandler(this.btnTLTT_Click);
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.picBoxLogo.Image = global::QLCHVBDQ.Properties.Resources.madrid;
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Padding = new System.Windows.Forms.Padding(5, 7, 5, 5);
            this.picBoxLogo.Size = new System.Drawing.Size(127, 129);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 1;
            this.picBoxLogo.TabStop = false;
            // 
            // btnLoaiNhanVien
            // 
            this.btnLoaiNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiNhanVien.FlatAppearance.BorderSize = 0;
            this.btnLoaiNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiNhanVien.ForeColor = System.Drawing.Color.White;
            this.btnLoaiNhanVien.Location = new System.Drawing.Point(0, 219);
            this.btnLoaiNhanVien.Name = "btnLoaiNhanVien";
            this.btnLoaiNhanVien.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiNhanVien.TabIndex = 16;
            this.btnLoaiNhanVien.Text = "Nhân viên";
            this.btnLoaiNhanVien.UseVisualStyleBackColor = false;
            this.btnLoaiNhanVien.Click += new System.EventHandler(this.btnLoaiNhanVien_Click);
            // 
            // btnCaiDat
            // 
            this.btnCaiDat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCaiDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaiDat.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnCaiDat.FlatAppearance.BorderSize = 0;
            this.btnCaiDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaiDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaiDat.ForeColor = System.Drawing.Color.Black;
            this.btnCaiDat.Location = new System.Drawing.Point(0, 131);
            this.btnCaiDat.Name = "btnCaiDat";
            this.btnCaiDat.Size = new System.Drawing.Size(127, 44);
            this.btnCaiDat.TabIndex = 14;
            this.btnCaiDat.Text = "Cài đặt";
            this.btnCaiDat.UseCompatibleTextRendering = true;
            this.btnCaiDat.UseVisualStyleBackColor = false;
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKhachHang.FlatAppearance.BorderSize = 0;
            this.btnKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.Location = new System.Drawing.Point(0, 175);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Size = new System.Drawing.Size(127, 44);
            this.btnKhachHang.TabIndex = 15;
            this.btnKhachHang.Text = "Khách hàng";
            this.btnKhachHang.UseVisualStyleBackColor = false;
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // textDsPDV
            // 
            this.textDsPDV.AutoSize = true;
            this.textDsPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDsPDV.Location = new System.Drawing.Point(21, 98);
            this.textDsPDV.Name = "textDsPDV";
            this.textDsPDV.Size = new System.Drawing.Size(487, 53);
            this.textDsPDV.TabIndex = 9;
            this.textDsPDV.Text = "Danh sách đơn vị tính";
            // 
            // dtgvDVT
            // 
            this.dtgvDVT.AllowUserToAddRows = false;
            this.dtgvDVT.AllowUserToDeleteRows = false;
            this.dtgvDVT.AllowUserToOrderColumns = true;
            this.dtgvDVT.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvDVT.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvDVT.BackgroundColor = System.Drawing.Color.White;
            this.dtgvDVT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvDVT.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvDVT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvDVT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDVT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtgvDVT.Location = new System.Drawing.Point(20, 175);
            this.dtgvDVT.Name = "dtgvDVT";
            this.dtgvDVT.ReadOnly = true;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvDVT.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvDVT.RowHeadersWidth = 62;
            this.dtgvDVT.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvDVT.RowTemplate.Height = 36;
            this.dtgvDVT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvDVT.ShowRowErrors = false;
            this.dtgvDVT.Size = new System.Drawing.Size(961, 465);
            this.dtgvDVT.TabIndex = 12;
            this.dtgvDVT.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvDVT_CellContentClick);
            // 
            // panelUserName
            // 
            this.panelUserName.Controls.Add(this.textUserName);
            this.panelUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelUserName.Location = new System.Drawing.Point(726, 19);
            this.panelUserName.Name = "panelUserName";
            this.panelUserName.Size = new System.Drawing.Size(255, 36);
            this.panelUserName.TabIndex = 13;
            // 
            // textUserName
            // 
            this.textUserName.AutoSize = true;
            this.textUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textUserName.Location = new System.Drawing.Point(0, 0);
            this.textUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(176, 29);
            this.textUserName.TabIndex = 6;
            this.textUserName.Text = "Nguyen Van A";
            // 
            // TrangChu
            // 
            this.TrangChu.AutoScroll = true;
            this.TrangChu.BackColor = System.Drawing.Color.White;
            this.TrangChu.Controls.Add(this.panelUserName);
            this.TrangChu.Controls.Add(this.dtgvDVT);
            this.TrangChu.Controls.Add(this.btnDeletes);
            this.TrangChu.Controls.Add(this.btnThemDVT);
            this.TrangChu.Controls.Add(this.textDsPDV);
            this.TrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangChu.Location = new System.Drawing.Point(127, 0);
            this.TrangChu.Margin = new System.Windows.Forms.Padding(0);
            this.TrangChu.Name = "TrangChu";
            this.TrangChu.Size = new System.Drawing.Size(990, 666);
            this.TrangChu.TabIndex = 1;
            // 
            // btnDeletes
            // 
            this.btnDeletes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeletes.Image = global::QLCHVBDQ.Properties.Resources.Trash_Full;
            this.btnDeletes.Location = new System.Drawing.Point(915, 98);
            this.btnDeletes.Name = "btnDeletes";
            this.btnDeletes.Size = new System.Drawing.Size(40, 40);
            this.btnDeletes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnDeletes.TabIndex = 11;
            this.btnDeletes.TabStop = false;
            this.btnDeletes.Click += new System.EventHandler(this.btnDeletes_Click);
            // 
            // btnThemDVT
            // 
            this.btnThemDVT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThemDVT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThemDVT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThemDVT.FlatAppearance.BorderSize = 0;
            this.btnThemDVT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemDVT.ForeColor = System.Drawing.Color.White;
            this.btnThemDVT.Image = global::QLCHVBDQ.Properties.Resources.Icon_plus;
            this.btnThemDVT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemDVT.Location = new System.Drawing.Point(621, 87);
            this.btnThemDVT.Name = "btnThemDVT";
            this.btnThemDVT.Padding = new System.Windows.Forms.Padding(10, 5, 0, 5);
            this.btnThemDVT.Size = new System.Drawing.Size(277, 62);
            this.btnThemDVT.TabIndex = 10;
            this.btnThemDVT.Text = "Thêm đơn vị tính";
            this.btnThemDVT.UseVisualStyleBackColor = false;
            this.btnThemDVT.Click += new System.EventHandler(this.btnThemDVT_Click);
            // 
            // fDVT
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1121, 666);
            this.Controls.Add(this.TrangChu);
            this.Controls.Add(this.DashboardTrangChu);
            this.Name = "fDVT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đơn vị tính";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.DashboardTrangChu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDVT)).EndInit();
            this.panelUserName.ResumeLayout(false);
            this.panelUserName.PerformLayout();
            this.TrangChu.ResumeLayout(false);
            this.TrangChu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeletes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DashboardTrangChu;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Button btnDVT;
        private System.Windows.Forms.Button btnTLTT;
        private System.Windows.Forms.Button btnLoaiNhanVien;
        private System.Windows.Forms.Button btnCaiDat;
        private System.Windows.Forms.Button btnKhachHang;
        private System.Windows.Forms.Label textDsPDV;
        private System.Windows.Forms.Button btnThemDVT;
        private System.Windows.Forms.PictureBox btnDeletes;
        private System.Windows.Forms.DataGridView dtgvDVT;
        private System.Windows.Forms.Panel panelUserName;
        private System.Windows.Forms.Label textUserName;
        private System.Windows.Forms.Panel TrangChu;
    }

}