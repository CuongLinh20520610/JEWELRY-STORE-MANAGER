﻿namespace QLCHVBDQ
{
    partial class fThemPMH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemPMH));
            this.btnThem = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dateNgayLapPhieu = new System.Windows.Forms.DateTimePicker();
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxSoPhieu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textTenNCC = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textThemPBH = new System.Windows.Forms.Label();
            this.comboBoxMaNCC = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(916, 565);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(481, 118);
            this.btnThem.TabIndex = 42;
            this.btnThem.Text = "Thêm phiếu mua hàng";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(816, 406);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(784, 2);
            this.label5.TabIndex = 47;
            // 
            // dateNgayLapPhieu
            // 
            this.dateNgayLapPhieu.CalendarForeColor = System.Drawing.Color.Black;
            this.dateNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateNgayLapPhieu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayLapPhieu.Location = new System.Drawing.Point(842, 285);
            this.dateNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateNgayLapPhieu.Name = "dateNgayLapPhieu";
            this.dateNgayLapPhieu.ShowUpDown = true;
            this.dateNgayLapPhieu.Size = new System.Drawing.Size(298, 48);
            this.dateNgayLapPhieu.TabIndex = 39;
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(836, 182);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(218, 32);
            this.textNgapLapPhieu.TabIndex = 45;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxSoPhieu
            // 
            this.textBoxSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSoPhieu.Location = new System.Drawing.Point(94, 271);
            this.textBoxSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSoPhieu.Name = "textBoxSoPhieu";
            this.textBoxSoPhieu.Size = new System.Drawing.Size(449, 43);
            this.textBoxSoPhieu.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(0, 405);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(749, 2);
            this.label9.TabIndex = 44;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(0, 117);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1594, 2);
            this.line1.TabIndex = 43;
            // 
            // textTenNCC
            // 
            this.textTenNCC.AutoSize = true;
            this.textTenNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenNCC.ForeColor = System.Drawing.Color.Black;
            this.textTenNCC.Location = new System.Drawing.Point(88, 449);
            this.textTenNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenNCC.Name = "textTenNCC";
            this.textTenNCC.Size = new System.Drawing.Size(245, 32);
            this.textTenNCC.TabIndex = 41;
            this.textTenNCC.Text = "Mã nhà cung cấp";
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textSoPhieu.Location = new System.Drawing.Point(88, 168);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(135, 32);
            this.textSoPhieu.TabIndex = 38;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textThemPBH
            // 
            this.textThemPBH.AutoSize = true;
            this.textThemPBH.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemPBH.Location = new System.Drawing.Point(69, 40);
            this.textThemPBH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemPBH.Name = "textThemPBH";
            this.textThemPBH.Size = new System.Drawing.Size(525, 55);
            this.textThemPBH.TabIndex = 36;
            this.textThemPBH.Text = "Thêm phiếu mua hàng";
            // 
            // comboBoxMaNCC
            // 
            this.comboBoxMaNCC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMaNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMaNCC.FormattingEnabled = true;
            this.comboBoxMaNCC.Location = new System.Drawing.Point(94, 540);
            this.comboBoxMaNCC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxMaNCC.Name = "comboBoxMaNCC";
            this.comboBoxMaNCC.Size = new System.Drawing.Size(448, 45);
            this.comboBoxMaNCC.TabIndex = 78;
            // 
            // fThemPMH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1536, 729);
            this.Controls.Add(this.comboBoxMaNCC);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateNgayLapPhieu);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxSoPhieu);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textTenNCC);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textThemPBH);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemPMH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm phiếu mua hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateNgayLapPhieu;
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxSoPhieu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textTenNCC;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textThemPBH;
        private System.Windows.Forms.ComboBox comboBoxMaNCC;
    }
}