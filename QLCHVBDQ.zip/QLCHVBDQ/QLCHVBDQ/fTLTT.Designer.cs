﻿namespace QLCHVBDQ
{
    partial class fTLTT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.DashboardTrangChu = new System.Windows.Forms.Panel();
            this.btnDVT = new System.Windows.Forms.Button();
            this.btnTLTT = new System.Windows.Forms.Button();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.btnLoaiNhanVien = new System.Windows.Forms.Button();
            this.btnCaiDat = new System.Windows.Forms.Button();
            this.btnKhachHang = new System.Windows.Forms.Button();
            this.textDsPDV = new System.Windows.Forms.Label();
            this.dtgvTLTT = new System.Windows.Forms.DataGridView();
            this.panelUserName = new System.Windows.Forms.Panel();
            this.textUserName = new System.Windows.Forms.Label();
            this.TrangChu = new System.Windows.Forms.Panel();
            this.DashboardTrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTLTT)).BeginInit();
            this.panelUserName.SuspendLayout();
            this.TrangChu.SuspendLayout();
            this.SuspendLayout();
            // 
            // DashboardTrangChu
            // 
            this.DashboardTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DashboardTrangChu.Controls.Add(this.btnDVT);
            this.DashboardTrangChu.Controls.Add(this.btnTLTT);
            this.DashboardTrangChu.Controls.Add(this.picBoxLogo);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiNhanVien);
            this.DashboardTrangChu.Controls.Add(this.btnCaiDat);
            this.DashboardTrangChu.Controls.Add(this.btnKhachHang);
            this.DashboardTrangChu.Location = new System.Drawing.Point(0, 0);
            this.DashboardTrangChu.Name = "DashboardTrangChu";
            this.DashboardTrangChu.Size = new System.Drawing.Size(127, 666);
            this.DashboardTrangChu.TabIndex = 0;
            // 
            // btnDVT
            // 
            this.btnDVT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDVT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDVT.FlatAppearance.BorderSize = 0;
            this.btnDVT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDVT.ForeColor = System.Drawing.Color.White;
            this.btnDVT.Location = new System.Drawing.Point(0, 307);
            this.btnDVT.Name = "btnDVT";
            this.btnDVT.Size = new System.Drawing.Size(127, 44);
            this.btnDVT.TabIndex = 18;
            this.btnDVT.Text = "Đơn vị tính";
            this.btnDVT.UseVisualStyleBackColor = false;
            this.btnDVT.Click += new System.EventHandler(this.btnDVT_Click);
            // 
            // btnTLTT
            // 
            this.btnTLTT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnTLTT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTLTT.FlatAppearance.BorderSize = 0;
            this.btnTLTT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTLTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTLTT.ForeColor = System.Drawing.Color.White;
            this.btnTLTT.Location = new System.Drawing.Point(0, 263);
            this.btnTLTT.Name = "btnTLTT";
            this.btnTLTT.Size = new System.Drawing.Size(127, 44);
            this.btnTLTT.TabIndex = 17;
            this.btnTLTT.Text = "Tham số";
            this.btnTLTT.UseVisualStyleBackColor = false;
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.picBoxLogo.Image = global::QLCHVBDQ.Properties.Resources.madrid;
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Padding = new System.Windows.Forms.Padding(5, 7, 5, 5);
            this.picBoxLogo.Size = new System.Drawing.Size(127, 129);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 1;
            this.picBoxLogo.TabStop = false;
            // 
            // btnLoaiNhanVien
            // 
            this.btnLoaiNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiNhanVien.FlatAppearance.BorderSize = 0;
            this.btnLoaiNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiNhanVien.ForeColor = System.Drawing.Color.White;
            this.btnLoaiNhanVien.Location = new System.Drawing.Point(0, 219);
            this.btnLoaiNhanVien.Name = "btnLoaiNhanVien";
            this.btnLoaiNhanVien.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiNhanVien.TabIndex = 16;
            this.btnLoaiNhanVien.Text = "Nhân viên";
            this.btnLoaiNhanVien.UseVisualStyleBackColor = false;
            this.btnLoaiNhanVien.Click += new System.EventHandler(this.btnLoaiNhanVien_Click);
            // 
            // btnCaiDat
            // 
            this.btnCaiDat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCaiDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaiDat.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnCaiDat.FlatAppearance.BorderSize = 0;
            this.btnCaiDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaiDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaiDat.ForeColor = System.Drawing.Color.Black;
            this.btnCaiDat.Location = new System.Drawing.Point(0, 131);
            this.btnCaiDat.Name = "btnCaiDat";
            this.btnCaiDat.Size = new System.Drawing.Size(127, 44);
            this.btnCaiDat.TabIndex = 14;
            this.btnCaiDat.Text = "Cài đặt";
            this.btnCaiDat.UseCompatibleTextRendering = true;
            this.btnCaiDat.UseVisualStyleBackColor = false;
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKhachHang.FlatAppearance.BorderSize = 0;
            this.btnKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.Location = new System.Drawing.Point(0, 175);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Size = new System.Drawing.Size(127, 44);
            this.btnKhachHang.TabIndex = 15;
            this.btnKhachHang.Text = "Khách hàng";
            this.btnKhachHang.UseVisualStyleBackColor = false;
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // textDsPDV
            // 
            this.textDsPDV.AutoSize = true;
            this.textDsPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDsPDV.Location = new System.Drawing.Point(14, 85);
            this.textDsPDV.Name = "textDsPDV";
            this.textDsPDV.Size = new System.Drawing.Size(437, 53);
            this.textDsPDV.TabIndex = 9;
            this.textDsPDV.Text = "Danh sách tham số";
            // 
            // dtgvTLTT
            // 
            this.dtgvTLTT.AllowUserToAddRows = false;
            this.dtgvTLTT.AllowUserToDeleteRows = false;
            this.dtgvTLTT.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvTLTT.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvTLTT.BackgroundColor = System.Drawing.Color.White;
            this.dtgvTLTT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvTLTT.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTLTT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvTLTT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTLTT.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvTLTT.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvTLTT.Location = new System.Drawing.Point(20, 131);
            this.dtgvTLTT.Name = "dtgvTLTT";
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTLTT.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dtgvTLTT.RowHeadersWidth = 62;
            this.dtgvTLTT.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvTLTT.RowTemplate.Height = 36;
            this.dtgvTLTT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvTLTT.ShowRowErrors = false;
            this.dtgvTLTT.Size = new System.Drawing.Size(961, 509);
            this.dtgvTLTT.TabIndex = 12;
            this.dtgvTLTT.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvTLTT_CellValueChanged);
            // 
            // panelUserName
            // 
            this.panelUserName.Controls.Add(this.textUserName);
            this.panelUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelUserName.Location = new System.Drawing.Point(726, 19);
            this.panelUserName.Name = "panelUserName";
            this.panelUserName.Size = new System.Drawing.Size(255, 36);
            this.panelUserName.TabIndex = 13;
            // 
            // textUserName
            // 
            this.textUserName.AutoSize = true;
            this.textUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textUserName.Location = new System.Drawing.Point(0, 0);
            this.textUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(176, 29);
            this.textUserName.TabIndex = 6;
            this.textUserName.Text = "Nguyen Van A";
            // 
            // TrangChu
            // 
            this.TrangChu.AutoScroll = true;
            this.TrangChu.BackColor = System.Drawing.Color.White;
            this.TrangChu.Controls.Add(this.panelUserName);
            this.TrangChu.Controls.Add(this.dtgvTLTT);
            this.TrangChu.Controls.Add(this.textDsPDV);
            this.TrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangChu.Location = new System.Drawing.Point(127, 0);
            this.TrangChu.Margin = new System.Windows.Forms.Padding(0);
            this.TrangChu.Name = "TrangChu";
            this.TrangChu.Size = new System.Drawing.Size(990, 666);
            this.TrangChu.TabIndex = 1;
            // 
            // fTLTT
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1121, 666);
            this.Controls.Add(this.TrangChu);
            this.Controls.Add(this.DashboardTrangChu);
            this.Name = "fTLTT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tham số";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.DashboardTrangChu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTLTT)).EndInit();
            this.panelUserName.ResumeLayout(false);
            this.panelUserName.PerformLayout();
            this.TrangChu.ResumeLayout(false);
            this.TrangChu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DashboardTrangChu;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Button btnDVT;
        private System.Windows.Forms.Button btnTLTT;
        private System.Windows.Forms.Button btnLoaiNhanVien;
        private System.Windows.Forms.Button btnCaiDat;
        private System.Windows.Forms.Button btnKhachHang;
        private System.Windows.Forms.Label textDsPDV;
        private System.Windows.Forms.DataGridView dtgvTLTT;
        private System.Windows.Forms.Panel panelUserName;
        private System.Windows.Forms.Label textUserName;
        private System.Windows.Forms.Panel TrangChu;
    }
}