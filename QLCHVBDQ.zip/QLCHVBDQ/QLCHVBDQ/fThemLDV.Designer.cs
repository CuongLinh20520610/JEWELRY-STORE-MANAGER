﻿namespace QLCHVBDQ
{
    partial class fThemLDV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemLDV));
            this.textBoxTenLDV = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textTenLDV = new System.Windows.Forms.Label();
            this.textBoxMaLDV = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textDonGia = new System.Windows.Forms.Label();
            this.textMaLDV = new System.Windows.Forms.Label();
            this.textThemLDV = new System.Windows.Forms.Label();
            this.numUDDonGia = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numUDDonGia)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxTenLDV
            // 
            this.textBoxTenLDV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenLDV.Location = new System.Drawing.Point(834, 280);
            this.textBoxTenLDV.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenLDV.Name = "textBoxTenLDV";
            this.textBoxTenLDV.Size = new System.Drawing.Size(449, 43);
            this.textBoxTenLDV.TabIndex = 94;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(991, 608);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(407, 95);
            this.btnThem.TabIndex = 86;
            this.btnThem.Text = "Thêm loại dịch vụ";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(832, 414);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(772, 2);
            this.label5.TabIndex = 91;
            // 
            // textTenLDV
            // 
            this.textTenLDV.AutoSize = true;
            this.textTenLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenLDV.ForeColor = System.Drawing.Color.Black;
            this.textTenLDV.Location = new System.Drawing.Point(828, 177);
            this.textTenLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenLDV.Name = "textTenLDV";
            this.textTenLDV.Size = new System.Drawing.Size(229, 32);
            this.textTenLDV.TabIndex = 89;
            this.textTenLDV.Text = "Tên loại dịch vụ";
            this.textTenLDV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMaLDV
            // 
            this.textBoxMaLDV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaLDV.Location = new System.Drawing.Point(93, 280);
            this.textBoxMaLDV.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxMaLDV.Name = "textBoxMaLDV";
            this.textBoxMaLDV.Size = new System.Drawing.Size(364, 43);
            this.textBoxMaLDV.TabIndex = 83;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(-3, 414);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(772, 2);
            this.label9.TabIndex = 88;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 138);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1612, 2);
            this.line1.TabIndex = 87;
            // 
            // textDonGia
            // 
            this.textDonGia.AutoSize = true;
            this.textDonGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDonGia.ForeColor = System.Drawing.Color.Black;
            this.textDonGia.Location = new System.Drawing.Point(87, 458);
            this.textDonGia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textDonGia.Name = "textDonGia";
            this.textDonGia.Size = new System.Drawing.Size(119, 32);
            this.textDonGia.TabIndex = 85;
            this.textDonGia.Text = "Đơn giá";
            // 
            // textMaLDV
            // 
            this.textMaLDV.AutoSize = true;
            this.textMaLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaLDV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textMaLDV.Location = new System.Drawing.Point(87, 177);
            this.textMaLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaLDV.Name = "textMaLDV";
            this.textMaLDV.Size = new System.Drawing.Size(218, 32);
            this.textMaLDV.TabIndex = 84;
            this.textMaLDV.Text = "Mã loại dịch vụ";
            // 
            // textThemLDV
            // 
            this.textThemLDV.AutoSize = true;
            this.textThemLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemLDV.Location = new System.Drawing.Point(68, 49);
            this.textThemLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemLDV.Name = "textThemLDV";
            this.textThemLDV.Size = new System.Drawing.Size(416, 55);
            this.textThemLDV.TabIndex = 82;
            this.textThemLDV.Text = "Thêm loại dịch vụ";
            // 
            // numUDDonGia
            // 
            this.numUDDonGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUDDonGia.Location = new System.Drawing.Point(93, 542);
            this.numUDDonGia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUDDonGia.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUDDonGia.Name = "numUDDonGia";
            this.numUDDonGia.Size = new System.Drawing.Size(309, 40);
            this.numUDDonGia.TabIndex = 96;
            // 
            // fThemLDV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1587, 731);
            this.Controls.Add(this.numUDDonGia);
            this.Controls.Add(this.textBoxTenLDV);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textTenLDV);
            this.Controls.Add(this.textBoxMaLDV);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textDonGia);
            this.Controls.Add(this.textMaLDV);
            this.Controls.Add(this.textThemLDV);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemLDV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm loại dịch vụ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fThemLDV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUDDonGia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTenLDV;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label textTenLDV;
        private System.Windows.Forms.TextBox textBoxMaLDV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textDonGia;
        private System.Windows.Forms.Label textMaLDV;
        private System.Windows.Forms.Label textThemLDV;
        private System.Windows.Forms.NumericUpDown numUDDonGia;
    }
}