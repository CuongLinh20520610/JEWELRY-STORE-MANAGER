﻿namespace QLCHVBDQ
{
    partial class fThemSP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemSP));
            this.comboBoxMaLSP = new System.Windows.Forms.ComboBox();
            this.numUDDonGia = new System.Windows.Forms.NumericUpDown();
            this.textBoxTenSP = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textDonGia = new System.Windows.Forms.Label();
            this.btnThem = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textTenSP = new System.Windows.Forms.Label();
            this.textBoxMaSP = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textLoaiSP = new System.Windows.Forms.Label();
            this.textMaSP = new System.Windows.Forms.Label();
            this.textThemSP = new System.Windows.Forms.Label();
            this.textTonKho = new System.Windows.Forms.Label();
            this.numUDTonKho = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numUDDonGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDTonKho)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxMaLSP
            // 
            this.comboBoxMaLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMaLSP.FormattingEnabled = true;
            this.comboBoxMaLSP.Location = new System.Drawing.Point(93, 548);
            this.comboBoxMaLSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxMaLSP.Name = "comboBoxMaLSP";
            this.comboBoxMaLSP.Size = new System.Drawing.Size(362, 45);
            this.comboBoxMaLSP.TabIndex = 96;
            // 
            // numUDDonGia
            // 
            this.numUDDonGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUDDonGia.Location = new System.Drawing.Point(834, 554);
            this.numUDDonGia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUDDonGia.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUDDonGia.Name = "numUDDonGia";
            this.numUDDonGia.Size = new System.Drawing.Size(450, 40);
            this.numUDDonGia.TabIndex = 95;
            // 
            // textBoxTenSP
            // 
            this.textBoxTenSP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenSP.Location = new System.Drawing.Point(834, 292);
            this.textBoxTenSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenSP.Name = "textBoxTenSP";
            this.textBoxTenSP.Size = new System.Drawing.Size(449, 43);
            this.textBoxTenSP.TabIndex = 94;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(832, 669);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(772, 2);
            this.label4.TabIndex = 93;
            // 
            // textDonGia
            // 
            this.textDonGia.AutoSize = true;
            this.textDonGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDonGia.ForeColor = System.Drawing.Color.Black;
            this.textDonGia.Location = new System.Drawing.Point(828, 471);
            this.textDonGia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textDonGia.Name = "textDonGia";
            this.textDonGia.Size = new System.Drawing.Size(119, 32);
            this.textDonGia.TabIndex = 92;
            this.textDonGia.Text = "Đơn giá";
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1108, 794);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(392, 95);
            this.btnThem.TabIndex = 86;
            this.btnThem.Text = "Thêm sản phẩm ";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(832, 426);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(772, 2);
            this.label5.TabIndex = 91;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(-3, 669);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(772, 2);
            this.label3.TabIndex = 90;
            // 
            // textTenSP
            // 
            this.textTenSP.AutoSize = true;
            this.textTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenSP.ForeColor = System.Drawing.Color.Black;
            this.textTenSP.Location = new System.Drawing.Point(828, 189);
            this.textTenSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenSP.Name = "textTenSP";
            this.textTenSP.Size = new System.Drawing.Size(206, 32);
            this.textTenSP.TabIndex = 89;
            this.textTenSP.Text = "Tên sản phẩm";
            this.textTenSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMaSP
            // 
            this.textBoxMaSP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaSP.Location = new System.Drawing.Point(93, 292);
            this.textBoxMaSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxMaSP.Name = "textBoxMaSP";
            this.textBoxMaSP.Size = new System.Drawing.Size(364, 43);
            this.textBoxMaSP.TabIndex = 83;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(-3, 426);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(772, 2);
            this.label9.TabIndex = 88;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 151);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1612, 2);
            this.line1.TabIndex = 87;
            // 
            // textLoaiSP
            // 
            this.textLoaiSP.AutoSize = true;
            this.textLoaiSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLoaiSP.ForeColor = System.Drawing.Color.Black;
            this.textLoaiSP.Location = new System.Drawing.Point(87, 471);
            this.textLoaiSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textLoaiSP.Name = "textLoaiSP";
            this.textLoaiSP.Size = new System.Drawing.Size(253, 32);
            this.textLoaiSP.TabIndex = 85;
            this.textLoaiSP.Text = "Mã loại sản phẩm";
            // 
            // textMaSP
            // 
            this.textMaSP.AutoSize = true;
            this.textMaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textMaSP.Location = new System.Drawing.Point(87, 189);
            this.textMaSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaSP.Name = "textMaSP";
            this.textMaSP.Size = new System.Drawing.Size(195, 32);
            this.textMaSP.TabIndex = 84;
            this.textMaSP.Text = "Mã sản phẩm";
            // 
            // textThemSP
            // 
            this.textThemSP.AutoSize = true;
            this.textThemSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemSP.Location = new System.Drawing.Point(68, 62);
            this.textThemSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemSP.Name = "textThemSP";
            this.textThemSP.Size = new System.Drawing.Size(385, 55);
            this.textThemSP.TabIndex = 82;
            this.textThemSP.Text = "Thêm sản phẩm";
            this.textThemSP.Click += new System.EventHandler(this.textThemSP_Click);
            // 
            // textTonKho
            // 
            this.textTonKho.AutoSize = true;
            this.textTonKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTonKho.ForeColor = System.Drawing.Color.Black;
            this.textTonKho.Location = new System.Drawing.Point(87, 743);
            this.textTonKho.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTonKho.Name = "textTonKho";
            this.textTonKho.Size = new System.Drawing.Size(123, 32);
            this.textTonKho.TabIndex = 97;
            this.textTonKho.Text = "Tồn kho";
            // 
            // numUDTonKho
            // 
            this.numUDTonKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUDTonKho.Location = new System.Drawing.Point(93, 823);
            this.numUDTonKho.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUDTonKho.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUDTonKho.Name = "numUDTonKho";
            this.numUDTonKho.Size = new System.Drawing.Size(364, 40);
            this.numUDTonKho.TabIndex = 98;
            // 
            // fThemSP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 962);
            this.Controls.Add(this.numUDTonKho);
            this.Controls.Add(this.textTonKho);
            this.Controls.Add(this.comboBoxMaLSP);
            this.Controls.Add(this.numUDDonGia);
            this.Controls.Add(this.textBoxTenSP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textDonGia);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textTenSP);
            this.Controls.Add(this.textBoxMaSP);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textLoaiSP);
            this.Controls.Add(this.textMaSP);
            this.Controls.Add(this.textThemSP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemSP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm sản phẩm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fThemSP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUDDonGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUDTonKho)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxMaLSP;
        private System.Windows.Forms.NumericUpDown numUDDonGia;
        private System.Windows.Forms.TextBox textBoxTenSP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label textDonGia;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label textTenSP;
        private System.Windows.Forms.TextBox textBoxMaSP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textLoaiSP;
        private System.Windows.Forms.Label textMaSP;
        private System.Windows.Forms.Label textThemSP;
        private System.Windows.Forms.Label textTonKho;
        private System.Windows.Forms.NumericUpDown numUDTonKho;
    }
}