﻿namespace QLCHVBDQ
{
    partial class fThemPBH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemPBH));
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textSDT = new System.Windows.Forms.Label();
            this.btnThem = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateNgayLapPhieu = new System.Windows.Forms.DateTimePicker();
            this.textBoxTenKH = new System.Windows.Forms.TextBox();
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxSoPhieu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textTenKH = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textThemPBH = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(810, 651);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(784, 2);
            this.label4.TabIndex = 35;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(836, 545);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.Size = new System.Drawing.Size(449, 43);
            this.textBoxSDT.TabIndex = 33;
            // 
            // textSDT
            // 
            this.textSDT.AutoSize = true;
            this.textSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSDT.ForeColor = System.Drawing.Color.Black;
            this.textSDT.Location = new System.Drawing.Point(830, 465);
            this.textSDT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSDT.Name = "textSDT";
            this.textSDT.Size = new System.Drawing.Size(194, 32);
            this.textSDT.TabIndex = 34;
            this.textSDT.Text = "Số điện thoại";
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1011, 752);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(497, 121);
            this.btnThem.TabIndex = 27;
            this.btnThem.Text = "Thêm phiếu bán hàng";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(810, 408);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(784, 2);
            this.label5.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(0, 663);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(764, 2);
            this.label3.TabIndex = 31;
            // 
            // dateNgayLapPhieu
            // 
            this.dateNgayLapPhieu.CalendarForeColor = System.Drawing.Color.Black;
            this.dateNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateNgayLapPhieu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayLapPhieu.Location = new System.Drawing.Point(836, 286);
            this.dateNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateNgayLapPhieu.Name = "dateNgayLapPhieu";
            this.dateNgayLapPhieu.ShowUpDown = true;
            this.dateNgayLapPhieu.Size = new System.Drawing.Size(298, 48);
            this.dateNgayLapPhieu.TabIndex = 24;
            // 
            // textBoxTenKH
            // 
            this.textBoxTenKH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenKH.Location = new System.Drawing.Point(94, 545);
            this.textBoxTenKH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenKH.Name = "textBoxTenKH";
            this.textBoxTenKH.Size = new System.Drawing.Size(449, 43);
            this.textBoxTenKH.TabIndex = 25;
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(830, 183);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(218, 32);
            this.textNgapLapPhieu.TabIndex = 30;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxSoPhieu
            // 
            this.textBoxSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSoPhieu.Location = new System.Drawing.Point(94, 286);
            this.textBoxSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSoPhieu.Name = "textBoxSoPhieu";
            this.textBoxSoPhieu.Size = new System.Drawing.Size(308, 43);
            this.textBoxSoPhieu.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(0, 420);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(764, 2);
            this.label9.TabIndex = 29;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(0, 132);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1594, 2);
            this.line1.TabIndex = 28;
            // 
            // textTenKH
            // 
            this.textTenKH.AutoSize = true;
            this.textTenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenKH.ForeColor = System.Drawing.Color.Black;
            this.textTenKH.Location = new System.Drawing.Point(88, 465);
            this.textTenKH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenKH.Name = "textTenKH";
            this.textTenKH.Size = new System.Drawing.Size(231, 32);
            this.textTenKH.TabIndex = 26;
            this.textTenKH.Text = "Tên khách hàng";
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textSoPhieu.Location = new System.Drawing.Point(88, 183);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(135, 32);
            this.textSoPhieu.TabIndex = 23;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textThemPBH
            // 
            this.textThemPBH.AutoSize = true;
            this.textThemPBH.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemPBH.Location = new System.Drawing.Point(69, 55);
            this.textThemPBH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemPBH.Name = "textThemPBH";
            this.textThemPBH.Size = new System.Drawing.Size(512, 55);
            this.textThemPBH.TabIndex = 21;
            this.textThemPBH.Text = "Thêm phiếu bán hàng";
            // 
            // fThemPBH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1586, 895);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textSDT);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateNgayLapPhieu);
            this.Controls.Add(this.textBoxTenKH);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxSoPhieu);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textTenKH);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textThemPBH);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximumSize = new System.Drawing.Size(1608, 951);
            this.Name = "fThemPBH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm phiếu bán hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.Label textSDT;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateNgayLapPhieu;
        private System.Windows.Forms.TextBox textBoxTenKH;
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxSoPhieu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textTenKH;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textThemPBH;
    }
}