﻿namespace QLCHVBDQ
{
    partial class fThemCTPDV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemCTPDV));
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxNewSoPhieu = new System.Windows.Forms.TextBox();
            this.line1 = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textThemCTPDV = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxKhachHang = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTraTruoc = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxConLai = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textBoxNgayLapPhieu = new System.Windows.Forms.TextBox();
            this.textBoxTinhTrang = new System.Windows.Forms.TextBox();
            this.textTinhTrang = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textCPRieng = new System.Windows.Forms.Label();
            this.dateNgayGiao = new System.Windows.Forms.DateTimePicker();
            this.textNgayGiao = new System.Windows.Forms.Label();
            this.textSoLuong = new System.Windows.Forms.Label();
            this.textLDV = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxTinhTrang = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textNewTinhTrang = new System.Windows.Forms.Label();
            this.textTraTruoc = new System.Windows.Forms.Label();
            this.comboBoxLDV = new System.Windows.Forms.ComboBox();
            this.numUpDowwnSoLuong = new System.Windows.Forms.NumericUpDown();
            this.numUpDownCPR = new System.Windows.Forms.NumericUpDown();
            this.nudTraTruoc = new System.Windows.Forms.NumericUpDown();
            this.btnThem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCPR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTraTruoc)).BeginInit();
            this.SuspendLayout();
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(850, 126);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(204, 32);
            this.textNgapLapPhieu.TabIndex = 26;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxNewSoPhieu
            // 
            this.textBoxNewSoPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNewSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNewSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewSoPhieu.Location = new System.Drawing.Point(302, 117);
            this.textBoxNewSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNewSoPhieu.Name = "textBoxNewSoPhieu";
            this.textBoxNewSoPhieu.ReadOnly = true;
            this.textBoxNewSoPhieu.Size = new System.Drawing.Size(484, 48);
            this.textBoxNewSoPhieu.TabIndex = 19;
            this.textBoxNewSoPhieu.TabStop = false;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 103);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1679, 2);
            this.line1.TabIndex = 24;
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.Black;
            this.textSoPhieu.Location = new System.Drawing.Point(110, 126);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(127, 32);
            this.textSoPhieu.TabIndex = 20;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textThemCTPDV
            // 
            this.textThemCTPDV.AutoSize = true;
            this.textThemCTPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemCTPDV.Location = new System.Drawing.Point(78, 28);
            this.textThemCTPDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemCTPDV.Name = "textThemCTPDV";
            this.textThemCTPDV.Size = new System.Drawing.Size(483, 55);
            this.textThemCTPDV.TabIndex = 18;
            this.textThemCTPDV.Text = "Thêm chi tiết dịch vụ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(850, 215);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 32);
            this.label2.TabIndex = 33;
            this.label2.Text = "Số điện thoại";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxKhachHang
            // 
            this.textBoxKhachHang.BackColor = System.Drawing.Color.White;
            this.textBoxKhachHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxKhachHang.Location = new System.Drawing.Point(302, 206);
            this.textBoxKhachHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxKhachHang.Name = "textBoxKhachHang";
            this.textBoxKhachHang.ReadOnly = true;
            this.textBoxKhachHang.Size = new System.Drawing.Size(484, 48);
            this.textBoxKhachHang.TabIndex = 29;
            this.textBoxKhachHang.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(110, 215);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 32);
            this.label6.TabIndex = 30;
            this.label6.Text = "Khách hàng";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(850, 298);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(223, 32);
            this.label8.TabIndex = 39;
            this.label8.Text = "Tổng tiền còn lại";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxTraTruoc
            // 
            this.textBoxTraTruoc.BackColor = System.Drawing.Color.White;
            this.textBoxTraTruoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTraTruoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTraTruoc.Location = new System.Drawing.Point(393, 289);
            this.textBoxTraTruoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTraTruoc.Name = "textBoxTraTruoc";
            this.textBoxTraTruoc.ReadOnly = true;
            this.textBoxTraTruoc.Size = new System.Drawing.Size(392, 48);
            this.textBoxTraTruoc.TabIndex = 35;
            this.textBoxTraTruoc.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(110, 298);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(243, 32);
            this.label11.TabIndex = 36;
            this.label11.Text = "Tổng tiền trả trước";
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.BackColor = System.Drawing.Color.White;
            this.textBoxTongTien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTongTien.Location = new System.Drawing.Point(393, 386);
            this.textBoxTongTien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.ReadOnly = true;
            this.textBoxTongTien.Size = new System.Drawing.Size(402, 48);
            this.textBoxTongTien.TabIndex = 41;
            this.textBoxTongTien.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(110, 395);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 32);
            this.label12.TabIndex = 42;
            this.label12.Text = "Tổng tiền";
            // 
            // textBoxConLai
            // 
            this.textBoxConLai.BackColor = System.Drawing.Color.White;
            this.textBoxConLai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxConLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConLai.Location = new System.Drawing.Point(1107, 298);
            this.textBoxConLai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxConLai.Name = "textBoxConLai";
            this.textBoxConLai.ReadOnly = true;
            this.textBoxConLai.Size = new System.Drawing.Size(530, 48);
            this.textBoxConLai.TabIndex = 43;
            this.textBoxConLai.TabStop = false;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BackColor = System.Drawing.Color.White;
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(1107, 206);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.ReadOnly = true;
            this.textBoxSDT.Size = new System.Drawing.Size(530, 48);
            this.textBoxSDT.TabIndex = 44;
            this.textBoxSDT.TabStop = false;
            // 
            // textBoxNgayLapPhieu
            // 
            this.textBoxNgayLapPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNgayLapPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNgayLapPhieu.Location = new System.Drawing.Point(1107, 117);
            this.textBoxNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNgayLapPhieu.Name = "textBoxNgayLapPhieu";
            this.textBoxNgayLapPhieu.ReadOnly = true;
            this.textBoxNgayLapPhieu.Size = new System.Drawing.Size(530, 48);
            this.textBoxNgayLapPhieu.TabIndex = 45;
            this.textBoxNgayLapPhieu.TabStop = false;
            // 
            // textBoxTinhTrang
            // 
            this.textBoxTinhTrang.BackColor = System.Drawing.Color.White;
            this.textBoxTinhTrang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTinhTrang.Location = new System.Drawing.Point(1107, 386);
            this.textBoxTinhTrang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTinhTrang.Name = "textBoxTinhTrang";
            this.textBoxTinhTrang.ReadOnly = true;
            this.textBoxTinhTrang.Size = new System.Drawing.Size(530, 48);
            this.textBoxTinhTrang.TabIndex = 48;
            this.textBoxTinhTrang.TabStop = false;
            // 
            // textTinhTrang
            // 
            this.textTinhTrang.AutoSize = true;
            this.textTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTinhTrang.ForeColor = System.Drawing.Color.Black;
            this.textTinhTrang.Location = new System.Drawing.Point(850, 395);
            this.textTinhTrang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTinhTrang.Name = "textTinhTrang";
            this.textTinhTrang.Size = new System.Drawing.Size(142, 32);
            this.textTinhTrang.TabIndex = 47;
            this.textTinhTrang.Text = "Tình trạng";
            this.textTinhTrang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(-12, 578);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1679, 2);
            this.label3.TabIndex = 50;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(582, 495);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(524, 55);
            this.label13.TabIndex = 49;
            this.label13.Text = "Nhập thông tin dịch vụ";
            // 
            // textCPRieng
            // 
            this.textCPRieng.AutoSize = true;
            this.textCPRieng.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCPRieng.ForeColor = System.Drawing.Color.Black;
            this.textCPRieng.Location = new System.Drawing.Point(850, 737);
            this.textCPRieng.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textCPRieng.Name = "textCPRieng";
            this.textCPRieng.Size = new System.Drawing.Size(187, 32);
            this.textCPRieng.TabIndex = 62;
            this.textCPRieng.Text = "Chi phí riêng";
            // 
            // dateNgayGiao
            // 
            this.dateNgayGiao.CalendarForeColor = System.Drawing.Color.Black;
            this.dateNgayGiao.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateNgayGiao.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNgayGiao.Location = new System.Drawing.Point(856, 643);
            this.dateNgayGiao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateNgayGiao.Name = "dateNgayGiao";
            this.dateNgayGiao.Size = new System.Drawing.Size(307, 48);
            this.dateNgayGiao.TabIndex = 53;
            // 
            // textNgayGiao
            // 
            this.textNgayGiao.AutoSize = true;
            this.textNgayGiao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgayGiao.ForeColor = System.Drawing.Color.Black;
            this.textNgayGiao.Location = new System.Drawing.Point(850, 602);
            this.textNgayGiao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgayGiao.Name = "textNgayGiao";
            this.textNgayGiao.Size = new System.Drawing.Size(151, 32);
            this.textNgayGiao.TabIndex = 58;
            this.textNgayGiao.Text = "Ngày giao";
            this.textNgayGiao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textSoLuong
            // 
            this.textSoLuong.AutoSize = true;
            this.textSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoLuong.ForeColor = System.Drawing.Color.Black;
            this.textSoLuong.Location = new System.Drawing.Point(110, 737);
            this.textSoLuong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoLuong.Name = "textSoLuong";
            this.textSoLuong.Size = new System.Drawing.Size(135, 32);
            this.textSoLuong.TabIndex = 55;
            this.textSoLuong.Text = "Số lượng";
            // 
            // textLDV
            // 
            this.textLDV.AutoSize = true;
            this.textLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLDV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textLDV.Location = new System.Drawing.Point(110, 602);
            this.textLDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textLDV.Name = "textLDV";
            this.textLDV.Size = new System.Drawing.Size(178, 32);
            this.textLDV.TabIndex = 52;
            this.textLDV.Text = "Loại dịch vụ";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Location = new System.Drawing.Point(854, 714);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(797, 2);
            this.label15.TabIndex = 66;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Location = new System.Drawing.Point(-16, 714);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(797, 2);
            this.label18.TabIndex = 65;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label14.Location = new System.Drawing.Point(854, 848);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(809, 2);
            this.label14.TabIndex = 69;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label16.Location = new System.Drawing.Point(-16, 848);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(797, 2);
            this.label16.TabIndex = 68;
            // 
            // comboBoxTinhTrang
            // 
            this.comboBoxTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxTinhTrang.FormattingEnabled = true;
            this.comboBoxTinhTrang.Items.AddRange(new object[] {
            "Chưa giao",
            "Đã giao"});
            this.comboBoxTinhTrang.Location = new System.Drawing.Point(854, 918);
            this.comboBoxTinhTrang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxTinhTrang.Name = "comboBoxTinhTrang";
            this.comboBoxTinhTrang.Size = new System.Drawing.Size(307, 45);
            this.comboBoxTinhTrang.TabIndex = 70;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Location = new System.Drawing.Point(854, 998);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(809, 2);
            this.label17.TabIndex = 76;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Location = new System.Drawing.Point(-6, 998);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(797, 2);
            this.label19.TabIndex = 75;
            // 
            // textNewTinhTrang
            // 
            this.textNewTinhTrang.AutoSize = true;
            this.textNewTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNewTinhTrang.ForeColor = System.Drawing.Color.Black;
            this.textNewTinhTrang.Location = new System.Drawing.Point(850, 877);
            this.textNewTinhTrang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNewTinhTrang.Name = "textNewTinhTrang";
            this.textNewTinhTrang.Size = new System.Drawing.Size(152, 32);
            this.textNewTinhTrang.TabIndex = 74;
            this.textNewTinhTrang.Text = "Tình trạng";
            // 
            // textTraTruoc
            // 
            this.textTraTruoc.AutoSize = true;
            this.textTraTruoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTraTruoc.ForeColor = System.Drawing.Color.Black;
            this.textTraTruoc.Location = new System.Drawing.Point(110, 877);
            this.textTraTruoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTraTruoc.Name = "textTraTruoc";
            this.textTraTruoc.Size = new System.Drawing.Size(135, 32);
            this.textTraTruoc.TabIndex = 72;
            this.textTraTruoc.Text = "Trả trước";
            // 
            // comboBoxLDV
            // 
            this.comboBoxLDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxLDV.FormattingEnabled = true;
            this.comboBoxLDV.Location = new System.Drawing.Point(116, 643);
            this.comboBoxLDV.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxLDV.Name = "comboBoxLDV";
            this.comboBoxLDV.Size = new System.Drawing.Size(416, 45);
            this.comboBoxLDV.TabIndex = 77;
            // 
            // numUpDowwnSoLuong
            // 
            this.numUpDowwnSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDowwnSoLuong.Location = new System.Drawing.Point(112, 782);
            this.numUpDowwnSoLuong.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUpDowwnSoLuong.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUpDowwnSoLuong.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDowwnSoLuong.Name = "numUpDowwnSoLuong";
            this.numUpDowwnSoLuong.Size = new System.Drawing.Size(309, 40);
            this.numUpDowwnSoLuong.TabIndex = 78;
            this.numUpDowwnSoLuong.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numUpDownCPR
            // 
            this.numUpDownCPR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDownCPR.Location = new System.Drawing.Point(856, 782);
            this.numUpDownCPR.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUpDownCPR.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUpDownCPR.Name = "numUpDownCPR";
            this.numUpDownCPR.Size = new System.Drawing.Size(309, 40);
            this.numUpDownCPR.TabIndex = 79;
            // 
            // nudTraTruoc
            // 
            this.nudTraTruoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudTraTruoc.Location = new System.Drawing.Point(116, 922);
            this.nudTraTruoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nudTraTruoc.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.nudTraTruoc.Name = "nudTraTruoc";
            this.nudTraTruoc.Size = new System.Drawing.Size(309, 40);
            this.nudTraTruoc.TabIndex = 80;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1322, 1037);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(248, 95);
            this.btnThem.TabIndex = 56;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // fThemCTPDV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1656, 1050);
            this.Controls.Add(this.nudTraTruoc);
            this.Controls.Add(this.numUpDownCPR);
            this.Controls.Add(this.numUpDowwnSoLuong);
            this.Controls.Add(this.comboBoxLDV);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textNewTinhTrang);
            this.Controls.Add(this.textTraTruoc);
            this.Controls.Add(this.comboBoxTinhTrang);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.textCPRieng);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.dateNgayGiao);
            this.Controls.Add(this.textNgayGiao);
            this.Controls.Add(this.textSoLuong);
            this.Controls.Add(this.textLDV);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBoxTinhTrang);
            this.Controls.Add(this.textTinhTrang);
            this.Controls.Add(this.textBoxNgayLapPhieu);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textBoxConLai);
            this.Controls.Add(this.textBoxTongTien);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxTraTruoc);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxKhachHang);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxNewSoPhieu);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textThemCTPDV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemCTPDV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm chi tiết phiếu dịch vụ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCPR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTraTruoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxNewSoPhieu;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textThemCTPDV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKhachHang;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxTraTruoc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxTongTien;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxConLai;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.TextBox textBoxNgayLapPhieu;
        private System.Windows.Forms.TextBox textBoxTinhTrang;
        private System.Windows.Forms.Label textTinhTrang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label textCPRieng;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DateTimePicker dateNgayGiao;
        private System.Windows.Forms.Label textNgayGiao;
        private System.Windows.Forms.Label textSoLuong;
        private System.Windows.Forms.Label textLDV;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxTinhTrang;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label textNewTinhTrang;
        private System.Windows.Forms.Label textTraTruoc;
        private System.Windows.Forms.ComboBox comboBoxLDV;
        private System.Windows.Forms.NumericUpDown numUpDowwnSoLuong;
        private System.Windows.Forms.NumericUpDown numUpDownCPR;
        private System.Windows.Forms.NumericUpDown nudTraTruoc;
    }
}