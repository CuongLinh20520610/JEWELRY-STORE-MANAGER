﻿namespace QLCHVBDQ
{
    partial class fThemNCC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemNCC));
            this.textBoxTenNCC = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textTenNCC = new System.Windows.Forms.Label();
            this.textBoxMaNCC = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textDiaChi = new System.Windows.Forms.Label();
            this.textMaNCC = new System.Windows.Forms.Label();
            this.textThemNCC = new System.Windows.Forms.Label();
            this.textBoxDiaChi = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxTenNCC
            // 
            this.textBoxTenNCC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenNCC.Location = new System.Drawing.Point(834, 280);
            this.textBoxTenNCC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenNCC.Name = "textBoxTenNCC";
            this.textBoxTenNCC.Size = new System.Drawing.Size(540, 43);
            this.textBoxTenNCC.TabIndex = 106;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1078, 763);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(451, 118);
            this.btnThem.TabIndex = 101;
            this.btnThem.Text = "Thêm nhà cung cấp";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(832, 414);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(772, 2);
            this.label5.TabIndex = 105;
            // 
            // textTenNCC
            // 
            this.textTenNCC.AutoSize = true;
            this.textTenNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenNCC.ForeColor = System.Drawing.Color.Black;
            this.textTenNCC.Location = new System.Drawing.Point(828, 177);
            this.textTenNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenNCC.Name = "textTenNCC";
            this.textTenNCC.Size = new System.Drawing.Size(256, 32);
            this.textTenNCC.TabIndex = 104;
            this.textTenNCC.Text = "Tên nhà cung cấp";
            this.textTenNCC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMaNCC
            // 
            this.textBoxMaNCC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaNCC.Location = new System.Drawing.Point(93, 280);
            this.textBoxMaNCC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxMaNCC.Name = "textBoxMaNCC";
            this.textBoxMaNCC.Size = new System.Drawing.Size(364, 43);
            this.textBoxMaNCC.TabIndex = 98;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(-3, 414);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(772, 2);
            this.label9.TabIndex = 103;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 138);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1612, 2);
            this.line1.TabIndex = 102;
            // 
            // textDiaChi
            // 
            this.textDiaChi.AutoSize = true;
            this.textDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDiaChi.ForeColor = System.Drawing.Color.Black;
            this.textDiaChi.Location = new System.Drawing.Point(828, 468);
            this.textDiaChi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textDiaChi.Name = "textDiaChi";
            this.textDiaChi.Size = new System.Drawing.Size(108, 32);
            this.textDiaChi.TabIndex = 100;
            this.textDiaChi.Text = "Địa chỉ";
            // 
            // textMaNCC
            // 
            this.textMaNCC.AutoSize = true;
            this.textMaNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaNCC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textMaNCC.Location = new System.Drawing.Point(87, 177);
            this.textMaNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaNCC.Name = "textMaNCC";
            this.textMaNCC.Size = new System.Drawing.Size(245, 32);
            this.textMaNCC.TabIndex = 99;
            this.textMaNCC.Text = "Mã nhà cung cấp";
            // 
            // textThemNCC
            // 
            this.textThemNCC.AutoSize = true;
            this.textThemNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemNCC.Location = new System.Drawing.Point(68, 49);
            this.textThemNCC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemNCC.Name = "textThemNCC";
            this.textThemNCC.Size = new System.Drawing.Size(467, 55);
            this.textThemNCC.TabIndex = 97;
            this.textThemNCC.Text = "Thêm nhà cung cấp";
            // 
            // textBoxDiaChi
            // 
            this.textBoxDiaChi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDiaChi.Location = new System.Drawing.Point(834, 574);
            this.textBoxDiaChi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxDiaChi.Name = "textBoxDiaChi";
            this.textBoxDiaChi.Size = new System.Drawing.Size(540, 43);
            this.textBoxDiaChi.TabIndex = 107;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(93, 574);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.Size = new System.Drawing.Size(382, 43);
            this.textBoxSDT.TabIndex = 109;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(87, 468);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 32);
            this.label1.TabIndex = 108;
            this.label1.Text = "Số điện thoại";
            // 
            // fThemNCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 909);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxDiaChi);
            this.Controls.Add(this.textBoxTenNCC);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textTenNCC);
            this.Controls.Add(this.textBoxMaNCC);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textDiaChi);
            this.Controls.Add(this.textMaNCC);
            this.Controls.Add(this.textThemNCC);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemNCC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm nhà cung cấp";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTenNCC;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label textTenNCC;
        private System.Windows.Forms.TextBox textBoxMaNCC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textDiaChi;
        private System.Windows.Forms.Label textMaNCC;
        private System.Windows.Forms.Label textThemNCC;
        private System.Windows.Forms.TextBox textBoxDiaChi;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.Label label1;
    }
}