﻿namespace QLCHVBDQ
{
    partial class fNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.DashboardTrangChu = new System.Windows.Forms.Panel();
            this.btnDVT = new System.Windows.Forms.Button();
            this.btnTLTT = new System.Windows.Forms.Button();
            this.btnLoaiNhanVien = new System.Windows.Forms.Button();
            this.btnKhachHang = new System.Windows.Forms.Button();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.btnCaiDat = new System.Windows.Forms.Button();
            this.TrangChu = new System.Windows.Forms.Panel();
            this.dtgvNV = new System.Windows.Forms.DataGridView();
            this.btnDeletesNV = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelUserName = new System.Windows.Forms.Panel();
            this.textUserName = new System.Windows.Forms.Label();
            this.dtgvQL = new System.Windows.Forms.DataGridView();
            this.textDsQL = new System.Windows.Forms.Label();
            this.DashboardTrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.TrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvNV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeletesNV)).BeginInit();
            this.panelUserName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQL)).BeginInit();
            this.SuspendLayout();
            // 
            // DashboardTrangChu
            // 
            this.DashboardTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DashboardTrangChu.Controls.Add(this.btnDVT);
            this.DashboardTrangChu.Controls.Add(this.btnTLTT);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiNhanVien);
            this.DashboardTrangChu.Controls.Add(this.btnKhachHang);
            this.DashboardTrangChu.Controls.Add(this.picBoxLogo);
            this.DashboardTrangChu.Controls.Add(this.btnCaiDat);
            this.DashboardTrangChu.Location = new System.Drawing.Point(0, 0);
            this.DashboardTrangChu.Name = "DashboardTrangChu";
            this.DashboardTrangChu.Size = new System.Drawing.Size(127, 761);
            this.DashboardTrangChu.TabIndex = 0;
            // 
            // btnDVT
            // 
            this.btnDVT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDVT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDVT.FlatAppearance.BorderSize = 0;
            this.btnDVT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDVT.ForeColor = System.Drawing.Color.White;
            this.btnDVT.Location = new System.Drawing.Point(0, 305);
            this.btnDVT.Name = "btnDVT";
            this.btnDVT.Size = new System.Drawing.Size(127, 44);
            this.btnDVT.TabIndex = 5;
            this.btnDVT.Text = "Đơn vị tính";
            this.btnDVT.UseVisualStyleBackColor = false;
            this.btnDVT.Click += new System.EventHandler(this.btnDVT_Click);
            // 
            // btnTLTT
            // 
            this.btnTLTT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTLTT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTLTT.FlatAppearance.BorderSize = 0;
            this.btnTLTT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTLTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTLTT.ForeColor = System.Drawing.Color.White;
            this.btnTLTT.Location = new System.Drawing.Point(0, 261);
            this.btnTLTT.Name = "btnTLTT";
            this.btnTLTT.Size = new System.Drawing.Size(127, 44);
            this.btnTLTT.TabIndex = 4;
            this.btnTLTT.Text = "Tham số";
            this.btnTLTT.UseVisualStyleBackColor = false;
            this.btnTLTT.Click += new System.EventHandler(this.btnTLTT_Click);
            // 
            // btnLoaiNhanVien
            // 
            this.btnLoaiNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnLoaiNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiNhanVien.FlatAppearance.BorderSize = 0;
            this.btnLoaiNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiNhanVien.ForeColor = System.Drawing.Color.White;
            this.btnLoaiNhanVien.Location = new System.Drawing.Point(0, 217);
            this.btnLoaiNhanVien.Name = "btnLoaiNhanVien";
            this.btnLoaiNhanVien.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiNhanVien.TabIndex = 3;
            this.btnLoaiNhanVien.Text = "Nhân viên";
            this.btnLoaiNhanVien.UseVisualStyleBackColor = false;
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKhachHang.FlatAppearance.BorderSize = 0;
            this.btnKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.Location = new System.Drawing.Point(0, 173);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Size = new System.Drawing.Size(127, 44);
            this.btnKhachHang.TabIndex = 2;
            this.btnKhachHang.Text = "Khách hàng";
            this.btnKhachHang.UseVisualStyleBackColor = false;
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.picBoxLogo.Image = global::QLCHVBDQ.Properties.Resources.madrid;
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Padding = new System.Windows.Forms.Padding(5, 7, 5, 5);
            this.picBoxLogo.Size = new System.Drawing.Size(127, 129);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 1;
            this.picBoxLogo.TabStop = false;
            // 
            // btnCaiDat
            // 
            this.btnCaiDat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCaiDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaiDat.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnCaiDat.FlatAppearance.BorderSize = 0;
            this.btnCaiDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaiDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaiDat.ForeColor = System.Drawing.Color.Black;
            this.btnCaiDat.Location = new System.Drawing.Point(0, 129);
            this.btnCaiDat.Name = "btnCaiDat";
            this.btnCaiDat.Size = new System.Drawing.Size(127, 44);
            this.btnCaiDat.TabIndex = 0;
            this.btnCaiDat.Text = "Cài đặt";
            this.btnCaiDat.UseCompatibleTextRendering = true;
            this.btnCaiDat.UseVisualStyleBackColor = false;
            // 
            // TrangChu
            // 
            this.TrangChu.AutoScroll = true;
            this.TrangChu.BackColor = System.Drawing.Color.White;
            this.TrangChu.Controls.Add(this.dtgvNV);
            this.TrangChu.Controls.Add(this.btnDeletesNV);
            this.TrangChu.Controls.Add(this.label1);
            this.TrangChu.Controls.Add(this.panelUserName);
            this.TrangChu.Controls.Add(this.dtgvQL);
            this.TrangChu.Controls.Add(this.textDsQL);
            this.TrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangChu.Location = new System.Drawing.Point(127, 0);
            this.TrangChu.Margin = new System.Windows.Forms.Padding(0);
            this.TrangChu.Name = "TrangChu";
            this.TrangChu.Size = new System.Drawing.Size(1069, 701);
            this.TrangChu.TabIndex = 1;
            // 
            // dtgvNV
            // 
            this.dtgvNV.AllowUserToAddRows = false;
            this.dtgvNV.AllowUserToDeleteRows = false;
            this.dtgvNV.AllowUserToOrderColumns = true;
            this.dtgvNV.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvNV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvNV.BackgroundColor = System.Drawing.Color.White;
            this.dtgvNV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvNV.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvNV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvNV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtgvNV.Location = new System.Drawing.Point(29, 423);
            this.dtgvNV.Name = "dtgvNV";
            this.dtgvNV.ReadOnly = true;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvNV.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvNV.RowHeadersWidth = 62;
            this.dtgvNV.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvNV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvNV.RowTemplate.Height = 36;
            this.dtgvNV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvNV.ShowRowErrors = false;
            this.dtgvNV.Size = new System.Drawing.Size(1021, 243);
            this.dtgvNV.TabIndex = 16;
            this.dtgvNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvNV_CellClick);
            // 
            // btnDeletesNV
            // 
            this.btnDeletesNV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeletesNV.Image = global::QLCHVBDQ.Properties.Resources.Trash_Full;
            this.btnDeletesNV.Location = new System.Drawing.Point(1010, 361);
            this.btnDeletesNV.Name = "btnDeletesNV";
            this.btnDeletesNV.Size = new System.Drawing.Size(40, 40);
            this.btnDeletesNV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnDeletesNV.TabIndex = 15;
            this.btnDeletesNV.TabStop = false;
            this.btnDeletesNV.Click += new System.EventHandler(this.btnDeletesNV_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 361);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(564, 53);
            this.label1.TabIndex = 14;
            this.label1.Text = "Danh sách các nhân viên";
            // 
            // panelUserName
            // 
            this.panelUserName.Controls.Add(this.textUserName);
            this.panelUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelUserName.Location = new System.Drawing.Point(795, 28);
            this.panelUserName.Name = "panelUserName";
            this.panelUserName.Size = new System.Drawing.Size(255, 36);
            this.panelUserName.TabIndex = 13;
            // 
            // textUserName
            // 
            this.textUserName.AutoSize = true;
            this.textUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textUserName.Location = new System.Drawing.Point(0, 0);
            this.textUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(176, 29);
            this.textUserName.TabIndex = 6;
            this.textUserName.Text = "Nguyen Van A";
            // 
            // dtgvQL
            // 
            this.dtgvQL.AllowUserToAddRows = false;
            this.dtgvQL.AllowUserToDeleteRows = false;
            this.dtgvQL.AllowUserToOrderColumns = true;
            this.dtgvQL.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvQL.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dtgvQL.BackgroundColor = System.Drawing.Color.White;
            this.dtgvQL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvQL.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvQL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dtgvQL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvQL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtgvQL.Location = new System.Drawing.Point(20, 129);
            this.dtgvQL.Name = "dtgvQL";
            this.dtgvQL.ReadOnly = true;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvQL.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dtgvQL.RowHeadersWidth = 62;
            this.dtgvQL.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dtgvQL.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvQL.RowTemplate.Height = 36;
            this.dtgvQL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvQL.ShowRowErrors = false;
            this.dtgvQL.Size = new System.Drawing.Size(1030, 200);
            this.dtgvQL.TabIndex = 12;
            this.dtgvQL.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvQL_CellClick);
            // 
            // textDsQL
            // 
            this.textDsQL.AutoSize = true;
            this.textDsQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDsQL.Location = new System.Drawing.Point(14, 73);
            this.textDsQL.Name = "textDsQL";
            this.textDsQL.Size = new System.Drawing.Size(510, 53);
            this.textDsQL.TabIndex = 9;
            this.textDsQL.Text = "Danh sách các quản lý";
            // 
            // fNhanVien
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1198, 697);
            this.Controls.Add(this.TrangChu);
            this.Controls.Add(this.DashboardTrangChu);
            this.Name = "fNhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cài đặt";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.DashboardTrangChu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.TrangChu.ResumeLayout(false);
            this.TrangChu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvNV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeletesNV)).EndInit();
            this.panelUserName.ResumeLayout(false);
            this.panelUserName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQL)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DashboardTrangChu;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Button btnCaiDat;
        private System.Windows.Forms.Button btnDVT;
        private System.Windows.Forms.Button btnTLTT;
        private System.Windows.Forms.Button btnLoaiNhanVien;
        private System.Windows.Forms.Button btnKhachHang;
        private System.Windows.Forms.Panel TrangChu;
        private System.Windows.Forms.Label textDsQL;
        private System.Windows.Forms.Panel panelUserName;
        private System.Windows.Forms.Label textUserName;
        private System.Windows.Forms.DataGridView dtgvQL;
        private System.Windows.Forms.DataGridView dtgvNV;
        private System.Windows.Forms.PictureBox btnDeletesNV;
        private System.Windows.Forms.Label label1;
    }

}