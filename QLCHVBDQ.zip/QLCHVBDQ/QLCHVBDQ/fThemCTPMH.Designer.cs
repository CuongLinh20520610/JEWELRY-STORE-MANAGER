﻿namespace QLCHVBDQ
{
    partial class fThemCTPMH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemCTPMH));
            this.numUpDowwnSoLuong = new System.Windows.Forms.NumericUpDown();
            this.comboBoxTenSP = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.textSoLuong = new System.Windows.Forms.Label();
            this.textTenSP = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxNgayLapPhieu = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNCC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxNewSoPhieu = new System.Windows.Forms.TextBox();
            this.line1 = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textThemCTPDV = new System.Windows.Forms.Label();
            this.textBoxDiaChi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // numUpDowwnSoLuong
            // 
            this.numUpDowwnSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDowwnSoLuong.Location = new System.Drawing.Point(828, 620);
            this.numUpDowwnSoLuong.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUpDowwnSoLuong.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUpDowwnSoLuong.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDowwnSoLuong.Name = "numUpDowwnSoLuong";
            this.numUpDowwnSoLuong.Size = new System.Drawing.Size(309, 40);
            this.numUpDowwnSoLuong.TabIndex = 136;
            this.numUpDowwnSoLuong.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // comboBoxTenSP
            // 
            this.comboBoxTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxTenSP.FormattingEnabled = true;
            this.comboBoxTenSP.Location = new System.Drawing.Point(93, 617);
            this.comboBoxTenSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxTenSP.Name = "comboBoxTenSP";
            this.comboBoxTenSP.Size = new System.Drawing.Size(416, 45);
            this.comboBoxTenSP.TabIndex = 135;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1159, 751);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(376, 114);
            this.btnThem.TabIndex = 134;
            this.btnThem.Text = "Thêm CTPMH";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // textSoLuong
            // 
            this.textSoLuong.AutoSize = true;
            this.textSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoLuong.ForeColor = System.Drawing.Color.Black;
            this.textSoLuong.Location = new System.Drawing.Point(825, 575);
            this.textSoLuong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoLuong.Name = "textSoLuong";
            this.textSoLuong.Size = new System.Drawing.Size(135, 32);
            this.textSoLuong.TabIndex = 133;
            this.textSoLuong.Text = "Số lượng";
            // 
            // textTenSP
            // 
            this.textTenSP.AutoSize = true;
            this.textTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textTenSP.Location = new System.Drawing.Point(87, 575);
            this.textTenSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenSP.Name = "textTenSP";
            this.textTenSP.Size = new System.Drawing.Size(206, 32);
            this.textTenSP.TabIndex = 132;
            this.textTenSP.Text = "Tên sản phẩm";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(-34, 552);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1679, 2);
            this.label3.TabIndex = 131;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(556, 475);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(585, 55);
            this.label13.TabIndex = 130;
            this.label13.Text = "Nhập thông tin sản phẩm";
            // 
            // textBoxNgayLapPhieu
            // 
            this.textBoxNgayLapPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNgayLapPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNgayLapPhieu.Location = new System.Drawing.Point(1078, 135);
            this.textBoxNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNgayLapPhieu.Name = "textBoxNgayLapPhieu";
            this.textBoxNgayLapPhieu.ReadOnly = true;
            this.textBoxNgayLapPhieu.Size = new System.Drawing.Size(455, 48);
            this.textBoxNgayLapPhieu.TabIndex = 129;
            this.textBoxNgayLapPhieu.TabStop = false;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BackColor = System.Drawing.Color.White;
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(1078, 251);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.ReadOnly = true;
            this.textBoxSDT.Size = new System.Drawing.Size(455, 48);
            this.textBoxSDT.TabIndex = 128;
            this.textBoxSDT.TabStop = false;
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.BackColor = System.Drawing.Color.White;
            this.textBoxTongTien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTongTien.Location = new System.Drawing.Point(1078, 355);
            this.textBoxTongTien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.ReadOnly = true;
            this.textBoxTongTien.Size = new System.Drawing.Size(455, 48);
            this.textBoxTongTien.TabIndex = 126;
            this.textBoxTongTien.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(822, 365);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 32);
            this.label11.TabIndex = 127;
            this.label11.Text = "Tổng tiền";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(822, 260);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 32);
            this.label2.TabIndex = 125;
            this.label2.Text = "Số điện thoại";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxNCC
            // 
            this.textBoxNCC.BackColor = System.Drawing.Color.White;
            this.textBoxNCC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNCC.Location = new System.Drawing.Point(273, 251);
            this.textBoxNCC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNCC.Name = "textBoxNCC";
            this.textBoxNCC.ReadOnly = true;
            this.textBoxNCC.Size = new System.Drawing.Size(484, 48);
            this.textBoxNCC.TabIndex = 123;
            this.textBoxNCC.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(54, 260);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(188, 32);
            this.label6.TabIndex = 124;
            this.label6.Text = "Nhà cung cấp";
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(822, 145);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(204, 32);
            this.textNgapLapPhieu.TabIndex = 122;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxNewSoPhieu
            // 
            this.textBoxNewSoPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNewSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNewSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewSoPhieu.Location = new System.Drawing.Point(273, 135);
            this.textBoxNewSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNewSoPhieu.Name = "textBoxNewSoPhieu";
            this.textBoxNewSoPhieu.ReadOnly = true;
            this.textBoxNewSoPhieu.Size = new System.Drawing.Size(484, 48);
            this.textBoxNewSoPhieu.TabIndex = 119;
            this.textBoxNewSoPhieu.TabStop = false;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-32, 122);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1679, 2);
            this.line1.TabIndex = 121;
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.Black;
            this.textSoPhieu.Location = new System.Drawing.Point(54, 145);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(127, 32);
            this.textSoPhieu.TabIndex = 120;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textThemCTPDV
            // 
            this.textThemCTPDV.AutoSize = true;
            this.textThemCTPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemCTPDV.Location = new System.Drawing.Point(50, 46);
            this.textThemCTPDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemCTPDV.Name = "textThemCTPDV";
            this.textThemCTPDV.Size = new System.Drawing.Size(684, 55);
            this.textThemCTPDV.TabIndex = 118;
            this.textThemCTPDV.Text = "Thêm chi tiết phiếu mua hàng";
            // 
            // textBoxDiaChi
            // 
            this.textBoxDiaChi.BackColor = System.Drawing.Color.White;
            this.textBoxDiaChi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDiaChi.Location = new System.Drawing.Point(273, 355);
            this.textBoxDiaChi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxDiaChi.Name = "textBoxDiaChi";
            this.textBoxDiaChi.ReadOnly = true;
            this.textBoxDiaChi.Size = new System.Drawing.Size(484, 48);
            this.textBoxDiaChi.TabIndex = 137;
            this.textBoxDiaChi.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(54, 365);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 32);
            this.label1.TabIndex = 138;
            this.label1.Text = "Địa chỉ";
            // 
            // fThemCTPMH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1602, 943);
            this.Controls.Add(this.textBoxDiaChi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numUpDowwnSoLuong);
            this.Controls.Add(this.comboBoxTenSP);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.textSoLuong);
            this.Controls.Add(this.textTenSP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBoxNgayLapPhieu);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textBoxTongTien);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxNCC);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxNewSoPhieu);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textThemCTPDV);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemCTPMH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm chi tiết phiếu mua hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numUpDowwnSoLuong;
        private System.Windows.Forms.ComboBox comboBoxTenSP;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label textSoLuong;
        private System.Windows.Forms.Label textTenSP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxNgayLapPhieu;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.TextBox textBoxTongTien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNCC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxNewSoPhieu;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textThemCTPDV;
        private System.Windows.Forms.TextBox textBoxDiaChi;
        private System.Windows.Forms.Label label1;
    }
}