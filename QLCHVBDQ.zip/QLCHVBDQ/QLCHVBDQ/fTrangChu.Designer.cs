﻿namespace QLCHVBDQ
{
    partial class fTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fTrangChu));
            this.DashboardTrangChu = new System.Windows.Forms.Panel();
            this.pictureBoxSetiting = new System.Windows.Forms.PictureBox();
            this.btnBaoCao = new System.Windows.Forms.Button();
            this.btnNCC = new System.Windows.Forms.Button();
            this.btnBanHang = new System.Windows.Forms.Button();
            this.btnMuaHang = new System.Windows.Forms.Button();
            this.btnLoaiDichVu = new System.Windows.Forms.Button();
            this.btnDichVu = new System.Windows.Forms.Button();
            this.btnLoaiSanPham = new System.Windows.Forms.Button();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.btnTrangChu = new System.Windows.Forms.Button();
            this.TrangChu = new System.Windows.Forms.Panel();
            this.btnThemPMH = new System.Windows.Forms.Button();
            this.panelTTTK = new System.Windows.Forms.Panel();
            this.buttonDangXuat = new System.Windows.Forms.Button();
            this.btnThongTinTaiKhoan = new System.Windows.Forms.Button();
            this.buttonThemPBH = new System.Windows.Forms.Button();
            this.panelUserName = new System.Windows.Forms.Panel();
            this.textUserName = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelNCC = new System.Windows.Forms.Panel();
            this.textNCC = new System.Windows.Forms.Label();
            this.SoNCC = new System.Windows.Forms.Label();
            this.panelDichVu = new System.Windows.Forms.Panel();
            this.textDichVu = new System.Windows.Forms.Label();
            this.SoDichVu = new System.Windows.Forms.Label();
            this.panelSanPham = new System.Windows.Forms.Panel();
            this.textSanPham = new System.Windows.Forms.Label();
            this.SoSanPham = new System.Windows.Forms.Label();
            this.imgNCC = new System.Windows.Forms.PictureBox();
            this.imgDichVu = new System.Windows.Forms.PictureBox();
            this.imgSanPham = new System.Windows.Forms.PictureBox();
            this.DashboardTrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetiting)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.TrangChu.SuspendLayout();
            this.panelTTTK.SuspendLayout();
            this.panelUserName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelNCC.SuspendLayout();
            this.panelDichVu.SuspendLayout();
            this.panelSanPham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgNCC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDichVu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // DashboardTrangChu
            // 
            this.DashboardTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DashboardTrangChu.Controls.Add(this.pictureBoxSetiting);
            this.DashboardTrangChu.Controls.Add(this.btnBaoCao);
            this.DashboardTrangChu.Controls.Add(this.btnNCC);
            this.DashboardTrangChu.Controls.Add(this.btnBanHang);
            this.DashboardTrangChu.Controls.Add(this.btnMuaHang);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiDichVu);
            this.DashboardTrangChu.Controls.Add(this.btnDichVu);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiSanPham);
            this.DashboardTrangChu.Controls.Add(this.btnSanPham);
            this.DashboardTrangChu.Controls.Add(this.picBoxLogo);
            this.DashboardTrangChu.Controls.Add(this.btnTrangChu);
            this.DashboardTrangChu.Location = new System.Drawing.Point(0, 0);
            this.DashboardTrangChu.Name = "DashboardTrangChu";
            this.DashboardTrangChu.Size = new System.Drawing.Size(127, 836);
            this.DashboardTrangChu.TabIndex = 0;
            // 
            // pictureBoxSetiting
            // 
            this.pictureBoxSetiting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxSetiting.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSetiting.Image")));
            this.pictureBoxSetiting.Location = new System.Drawing.Point(40, 697);
            this.pictureBoxSetiting.Name = "pictureBoxSetiting";
            this.pictureBoxSetiting.Size = new System.Drawing.Size(45, 45);
            this.pictureBoxSetiting.TabIndex = 10;
            this.pictureBoxSetiting.TabStop = false;
            this.pictureBoxSetiting.Visible = false;
            this.pictureBoxSetiting.Click += new System.EventHandler(this.pictureBoxSetiting_Click);
            // 
            // btnBaoCao
            // 
            this.btnBaoCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBaoCao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBaoCao.FlatAppearance.BorderSize = 0;
            this.btnBaoCao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBaoCao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaoCao.ForeColor = System.Drawing.Color.White;
            this.btnBaoCao.Location = new System.Drawing.Point(0, 481);
            this.btnBaoCao.Margin = new System.Windows.Forms.Padding(0);
            this.btnBaoCao.Name = "btnBaoCao";
            this.btnBaoCao.Size = new System.Drawing.Size(127, 44);
            this.btnBaoCao.TabIndex = 9;
            this.btnBaoCao.Text = "Báo cáo";
            this.btnBaoCao.UseVisualStyleBackColor = false;
            this.btnBaoCao.Click += new System.EventHandler(this.btnBaoCao_Click);
            // 
            // btnNCC
            // 
            this.btnNCC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnNCC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNCC.FlatAppearance.BorderSize = 0;
            this.btnNCC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNCC.ForeColor = System.Drawing.Color.White;
            this.btnNCC.Location = new System.Drawing.Point(0, 437);
            this.btnNCC.Name = "btnNCC";
            this.btnNCC.Size = new System.Drawing.Size(127, 44);
            this.btnNCC.TabIndex = 8;
            this.btnNCC.Text = "Nhà cung cấp";
            this.btnNCC.UseVisualStyleBackColor = false;
            this.btnNCC.Click += new System.EventHandler(this.btnNCC_Click);
            // 
            // btnBanHang
            // 
            this.btnBanHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBanHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBanHang.FlatAppearance.BorderSize = 0;
            this.btnBanHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBanHang.ForeColor = System.Drawing.Color.White;
            this.btnBanHang.Location = new System.Drawing.Point(0, 393);
            this.btnBanHang.Name = "btnBanHang";
            this.btnBanHang.Size = new System.Drawing.Size(127, 44);
            this.btnBanHang.TabIndex = 7;
            this.btnBanHang.Text = "Bán hàng";
            this.btnBanHang.UseVisualStyleBackColor = false;
            this.btnBanHang.Click += new System.EventHandler(this.btnBanHang_Click);
            // 
            // btnMuaHang
            // 
            this.btnMuaHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnMuaHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMuaHang.FlatAppearance.BorderSize = 0;
            this.btnMuaHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMuaHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuaHang.ForeColor = System.Drawing.Color.White;
            this.btnMuaHang.Location = new System.Drawing.Point(0, 349);
            this.btnMuaHang.Name = "btnMuaHang";
            this.btnMuaHang.Size = new System.Drawing.Size(127, 44);
            this.btnMuaHang.TabIndex = 6;
            this.btnMuaHang.Text = "Mua Hàng";
            this.btnMuaHang.UseVisualStyleBackColor = false;
            this.btnMuaHang.Click += new System.EventHandler(this.btnMuaHang_Click);
            // 
            // btnLoaiDichVu
            // 
            this.btnLoaiDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiDichVu.FlatAppearance.BorderSize = 0;
            this.btnLoaiDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiDichVu.ForeColor = System.Drawing.Color.White;
            this.btnLoaiDichVu.Location = new System.Drawing.Point(0, 305);
            this.btnLoaiDichVu.Name = "btnLoaiDichVu";
            this.btnLoaiDichVu.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiDichVu.TabIndex = 5;
            this.btnLoaiDichVu.Text = "Loại dịch vụ";
            this.btnLoaiDichVu.UseVisualStyleBackColor = false;
            this.btnLoaiDichVu.Click += new System.EventHandler(this.btnLoaiDichVu_Click);
            // 
            // btnDichVu
            // 
            this.btnDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDichVu.FlatAppearance.BorderSize = 0;
            this.btnDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDichVu.ForeColor = System.Drawing.Color.White;
            this.btnDichVu.Location = new System.Drawing.Point(0, 261);
            this.btnDichVu.Name = "btnDichVu";
            this.btnDichVu.Size = new System.Drawing.Size(127, 44);
            this.btnDichVu.TabIndex = 4;
            this.btnDichVu.Text = "Dịch vụ";
            this.btnDichVu.UseVisualStyleBackColor = false;
            this.btnDichVu.Click += new System.EventHandler(this.btnDichVu_Click);
            // 
            // btnLoaiSanPham
            // 
            this.btnLoaiSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiSanPham.FlatAppearance.BorderSize = 0;
            this.btnLoaiSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiSanPham.ForeColor = System.Drawing.Color.White;
            this.btnLoaiSanPham.Location = new System.Drawing.Point(0, 217);
            this.btnLoaiSanPham.Name = "btnLoaiSanPham";
            this.btnLoaiSanPham.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiSanPham.TabIndex = 3;
            this.btnLoaiSanPham.Text = "Loại sản phẩm";
            this.btnLoaiSanPham.UseVisualStyleBackColor = false;
            this.btnLoaiSanPham.Click += new System.EventHandler(this.btnLoaiSanPham_Click);
            // 
            // btnSanPham
            // 
            this.btnSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSanPham.FlatAppearance.BorderSize = 0;
            this.btnSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.ForeColor = System.Drawing.Color.White;
            this.btnSanPham.Location = new System.Drawing.Point(0, 173);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(127, 44);
            this.btnSanPham.TabIndex = 2;
            this.btnSanPham.Text = "Sản Phẩm";
            this.btnSanPham.UseVisualStyleBackColor = false;
            this.btnSanPham.Click += new System.EventHandler(this.btnSanPham_Click);
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.picBoxLogo.Image = global::QLCHVBDQ.Properties.Resources.madrid;
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Padding = new System.Windows.Forms.Padding(5, 7, 5, 5);
            this.picBoxLogo.Size = new System.Drawing.Size(127, 129);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 1;
            this.picBoxLogo.TabStop = false;
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnTrangChu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTrangChu.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnTrangChu.FlatAppearance.BorderSize = 0;
            this.btnTrangChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangChu.ForeColor = System.Drawing.Color.White;
            this.btnTrangChu.Location = new System.Drawing.Point(0, 129);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(127, 44);
            this.btnTrangChu.TabIndex = 0;
            this.btnTrangChu.Text = "Trang chủ";
            this.btnTrangChu.UseCompatibleTextRendering = true;
            this.btnTrangChu.UseVisualStyleBackColor = false;
            // 
            // TrangChu
            // 
            this.TrangChu.BackColor = System.Drawing.Color.White;
            this.TrangChu.Controls.Add(this.btnThemPMH);
            this.TrangChu.Controls.Add(this.panelTTTK);
            this.TrangChu.Controls.Add(this.buttonThemPBH);
            this.TrangChu.Controls.Add(this.panelUserName);
            this.TrangChu.Controls.Add(this.panelNCC);
            this.TrangChu.Controls.Add(this.panelDichVu);
            this.TrangChu.Controls.Add(this.panelSanPham);
            this.TrangChu.Controls.Add(this.imgNCC);
            this.TrangChu.Controls.Add(this.imgDichVu);
            this.TrangChu.Controls.Add(this.imgSanPham);
            this.TrangChu.Location = new System.Drawing.Point(127, 0);
            this.TrangChu.Margin = new System.Windows.Forms.Padding(0);
            this.TrangChu.Name = "TrangChu";
            this.TrangChu.Size = new System.Drawing.Size(1138, 833);
            this.TrangChu.TabIndex = 1;
            // 
            // btnThemPMH
            // 
            this.btnThemPMH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThemPMH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThemPMH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThemPMH.FlatAppearance.BorderSize = 0;
            this.btnThemPMH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemPMH.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPMH.ForeColor = System.Drawing.Color.White;
            this.btnThemPMH.Image = ((System.Drawing.Image)(resources.GetObject("btnThemPMH.Image")));
            this.btnThemPMH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemPMH.Location = new System.Drawing.Point(161, 637);
            this.btnThemPMH.Name = "btnThemPMH";
            this.btnThemPMH.Padding = new System.Windows.Forms.Padding(10);
            this.btnThemPMH.Size = new System.Drawing.Size(340, 64);
            this.btnThemPMH.TabIndex = 0;
            this.btnThemPMH.Text = "Thêm phiếu mua hàng";
            this.btnThemPMH.UseVisualStyleBackColor = false;
            this.btnThemPMH.Click += new System.EventHandler(this.btnMuaHang_Click);
            // 
            // panelTTTK
            // 
            this.panelTTTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panelTTTK.Controls.Add(this.buttonDangXuat);
            this.panelTTTK.Controls.Add(this.btnThongTinTaiKhoan);
            this.panelTTTK.Location = new System.Drawing.Point(805, 59);
            this.panelTTTK.Name = "panelTTTK";
            this.panelTTTK.Size = new System.Drawing.Size(118, 74);
            this.panelTTTK.TabIndex = 7;
            this.panelTTTK.Visible = false;
            // 
            // buttonDangXuat
            // 
            this.buttonDangXuat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonDangXuat.FlatAppearance.BorderSize = 0;
            this.buttonDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDangXuat.Location = new System.Drawing.Point(2, 34);
            this.buttonDangXuat.Margin = new System.Windows.Forms.Padding(1);
            this.buttonDangXuat.Name = "buttonDangXuat";
            this.buttonDangXuat.Size = new System.Drawing.Size(115, 32);
            this.buttonDangXuat.TabIndex = 3;
            this.buttonDangXuat.Text = "Đăng xuất";
            this.buttonDangXuat.UseVisualStyleBackColor = false;
            this.buttonDangXuat.Click += new System.EventHandler(this.buttonDangXuat_Click);
            // 
            // btnThongTinTaiKhoan
            // 
            this.btnThongTinTaiKhoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThongTinTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btnThongTinTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThongTinTaiKhoan.Location = new System.Drawing.Point(1, 0);
            this.btnThongTinTaiKhoan.Margin = new System.Windows.Forms.Padding(1);
            this.btnThongTinTaiKhoan.Name = "btnThongTinTaiKhoan";
            this.btnThongTinTaiKhoan.Size = new System.Drawing.Size(115, 32);
            this.btnThongTinTaiKhoan.TabIndex = 2;
            this.btnThongTinTaiKhoan.Text = "Thông tin tài khoản";
            this.btnThongTinTaiKhoan.UseVisualStyleBackColor = false;
            this.btnThongTinTaiKhoan.Click += new System.EventHandler(this.btnThongTinTaiKhoan_Click);
            // 
            // buttonThemPBH
            // 
            this.buttonThemPBH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonThemPBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonThemPBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonThemPBH.FlatAppearance.BorderSize = 0;
            this.buttonThemPBH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonThemPBH.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonThemPBH.ForeColor = System.Drawing.Color.White;
            this.buttonThemPBH.Image = ((System.Drawing.Image)(resources.GetObject("buttonThemPBH.Image")));
            this.buttonThemPBH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonThemPBH.Location = new System.Drawing.Point(659, 637);
            this.buttonThemPBH.Name = "buttonThemPBH";
            this.buttonThemPBH.Padding = new System.Windows.Forms.Padding(10);
            this.buttonThemPBH.Size = new System.Drawing.Size(340, 64);
            this.buttonThemPBH.TabIndex = 1;
            this.buttonThemPBH.Text = "Thêm phiếu bán hàng";
            this.buttonThemPBH.UseVisualStyleBackColor = false;
            this.buttonThemPBH.Click += new System.EventHandler(this.btnBanHang_Click);
            // 
            // panelUserName
            // 
            this.panelUserName.AutoSize = true;
            this.panelUserName.Controls.Add(this.textUserName);
            this.panelUserName.Controls.Add(this.pictureBox3);
            this.panelUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelUserName.Location = new System.Drawing.Point(805, 23);
            this.panelUserName.Name = "panelUserName";
            this.panelUserName.Size = new System.Drawing.Size(289, 39);
            this.panelUserName.TabIndex = 5;
            // 
            // textUserName
            // 
            this.textUserName.AutoSize = true;
            this.textUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textUserName.Location = new System.Drawing.Point(27, 4);
            this.textUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(176, 29);
            this.textUserName.TabIndex = 6;
            this.textUserName.Text = "Nguyen Van A";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 34);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panelNCC
            // 
            this.panelNCC.Controls.Add(this.textNCC);
            this.panelNCC.Controls.Add(this.SoNCC);
            this.panelNCC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelNCC.Location = new System.Drawing.Point(801, 465);
            this.panelNCC.Name = "panelNCC";
            this.panelNCC.Size = new System.Drawing.Size(296, 76);
            this.panelNCC.TabIndex = 4;
            // 
            // textNCC
            // 
            this.textNCC.AutoSize = true;
            this.textNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNCC.Location = new System.Drawing.Point(100, 24);
            this.textNCC.Name = "textNCC";
            this.textNCC.Size = new System.Drawing.Size(267, 46);
            this.textNCC.TabIndex = 1;
            this.textNCC.Text = "Nhà cung cấp";
            this.textNCC.Click += new System.EventHandler(this.textNCC_Click);
            // 
            // SoNCC
            // 
            this.SoNCC.AutoSize = true;
            this.SoNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoNCC.ForeColor = System.Drawing.Color.Red;
            this.SoNCC.Location = new System.Drawing.Point(3, 21);
            this.SoNCC.Name = "SoNCC";
            this.SoNCC.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SoNCC.Size = new System.Drawing.Size(136, 55);
            this.SoNCC.TabIndex = 0;
            this.SoNCC.Text = "1000";
            this.SoNCC.Click += new System.EventHandler(this.SoNCC_Click);
            // 
            // panelDichVu
            // 
            this.panelDichVu.Controls.Add(this.textDichVu);
            this.panelDichVu.Controls.Add(this.SoDichVu);
            this.panelDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelDichVu.Location = new System.Drawing.Point(426, 465);
            this.panelDichVu.Name = "panelDichVu";
            this.panelDichVu.Size = new System.Drawing.Size(296, 76);
            this.panelDichVu.TabIndex = 4;
            // 
            // textDichVu
            // 
            this.textDichVu.AutoSize = true;
            this.textDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDichVu.Location = new System.Drawing.Point(166, 21);
            this.textDichVu.Name = "textDichVu";
            this.textDichVu.Size = new System.Drawing.Size(153, 46);
            this.textDichVu.TabIndex = 1;
            this.textDichVu.Text = "Dịch vụ";
            this.textDichVu.Click += new System.EventHandler(this.textDichVu_Click);
            // 
            // SoDichVu
            // 
            this.SoDichVu.AutoSize = true;
            this.SoDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoDichVu.ForeColor = System.Drawing.Color.Red;
            this.SoDichVu.Location = new System.Drawing.Point(3, 18);
            this.SoDichVu.Name = "SoDichVu";
            this.SoDichVu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SoDichVu.Size = new System.Drawing.Size(136, 55);
            this.SoDichVu.TabIndex = 0;
            this.SoDichVu.Text = "1500";
            this.SoDichVu.Click += new System.EventHandler(this.SoDichVu_Click);
            // 
            // panelSanPham
            // 
            this.panelSanPham.Controls.Add(this.textSanPham);
            this.panelSanPham.Controls.Add(this.SoSanPham);
            this.panelSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelSanPham.Location = new System.Drawing.Point(70, 465);
            this.panelSanPham.Name = "panelSanPham";
            this.panelSanPham.Size = new System.Drawing.Size(270, 76);
            this.panelSanPham.TabIndex = 3;
            // 
            // textSanPham
            // 
            this.textSanPham.AutoSize = true;
            this.textSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSanPham.Location = new System.Drawing.Point(111, 21);
            this.textSanPham.Name = "textSanPham";
            this.textSanPham.Size = new System.Drawing.Size(201, 46);
            this.textSanPham.TabIndex = 1;
            this.textSanPham.Text = "Sản phẩm";
            this.textSanPham.Click += new System.EventHandler(this.textSanPham_Click);
            // 
            // SoSanPham
            // 
            this.SoSanPham.AutoSize = true;
            this.SoSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoSanPham.ForeColor = System.Drawing.Color.Red;
            this.SoSanPham.Location = new System.Drawing.Point(3, 21);
            this.SoSanPham.Name = "SoSanPham";
            this.SoSanPham.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SoSanPham.Size = new System.Drawing.Size(136, 55);
            this.SoSanPham.TabIndex = 0;
            this.SoSanPham.Text = "2500";
            this.SoSanPham.Click += new System.EventHandler(this.SoSanPham_Click);
            // 
            // imgNCC
            // 
            this.imgNCC.Image = global::QLCHVBDQ.Properties.Resources.seller;
            this.imgNCC.Location = new System.Drawing.Point(801, 173);
            this.imgNCC.Name = "imgNCC";
            this.imgNCC.Size = new System.Drawing.Size(265, 250);
            this.imgNCC.TabIndex = 2;
            this.imgNCC.TabStop = false;
            // 
            // imgDichVu
            // 
            this.imgDichVu.Image = global::QLCHVBDQ.Properties.Resources.ser;
            this.imgDichVu.Location = new System.Drawing.Point(426, 173);
            this.imgDichVu.Name = "imgDichVu";
            this.imgDichVu.Size = new System.Drawing.Size(271, 250);
            this.imgDichVu.TabIndex = 1;
            this.imgDichVu.TabStop = false;
            // 
            // imgSanPham
            // 
            this.imgSanPham.Image = global::QLCHVBDQ.Properties.Resources.prd;
            this.imgSanPham.Location = new System.Drawing.Point(70, 173);
            this.imgSanPham.Name = "imgSanPham";
            this.imgSanPham.Size = new System.Drawing.Size(250, 250);
            this.imgSanPham.TabIndex = 0;
            this.imgSanPham.TabStop = false;
            // 
            // fTrangChu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1278, 819);
            this.Controls.Add(this.TrangChu);
            this.Controls.Add(this.DashboardTrangChu);
            this.MaximumSize = new System.Drawing.Size(1300, 875);
            this.Name = "fTrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trang Chủ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.DashboardTrangChu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSetiting)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.TrangChu.ResumeLayout(false);
            this.TrangChu.PerformLayout();
            this.panelTTTK.ResumeLayout(false);
            this.panelUserName.ResumeLayout(false);
            this.panelUserName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelNCC.ResumeLayout(false);
            this.panelNCC.PerformLayout();
            this.panelDichVu.ResumeLayout(false);
            this.panelDichVu.PerformLayout();
            this.panelSanPham.ResumeLayout(false);
            this.panelSanPham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgNCC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgDichVu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSanPham)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DashboardTrangChu;
        private System.Windows.Forms.Panel TrangChu;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Button btnTrangChu;
        private System.Windows.Forms.Button btnBaoCao;
        private System.Windows.Forms.Button btnNCC;
        private System.Windows.Forms.Button btnBanHang;
        private System.Windows.Forms.Button btnMuaHang;
        private System.Windows.Forms.Button btnLoaiDichVu;
        private System.Windows.Forms.Button btnDichVu;
        private System.Windows.Forms.Button btnLoaiSanPham;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.Panel panelSanPham;
        private System.Windows.Forms.Label textSanPham;
        private System.Windows.Forms.Label SoSanPham;
        private System.Windows.Forms.PictureBox imgNCC;
        private System.Windows.Forms.PictureBox imgDichVu;
        private System.Windows.Forms.PictureBox imgSanPham;
        private System.Windows.Forms.Panel panelDichVu;
        private System.Windows.Forms.Label textDichVu;
        private System.Windows.Forms.Label SoDichVu;
        private System.Windows.Forms.PictureBox pictureBoxSetiting;
        private System.Windows.Forms.Panel panelNCC;
        private System.Windows.Forms.Label textNCC;
        private System.Windows.Forms.Label SoNCC;
        private System.Windows.Forms.Panel panelUserName;
        private System.Windows.Forms.Label textUserName;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button buttonThemPBH;
        private System.Windows.Forms.Button btnThemPMH;
        private System.Windows.Forms.Panel panelTTTK;
        private System.Windows.Forms.Button buttonDangXuat;
        private System.Windows.Forms.Button btnThongTinTaiKhoan;
    }
}