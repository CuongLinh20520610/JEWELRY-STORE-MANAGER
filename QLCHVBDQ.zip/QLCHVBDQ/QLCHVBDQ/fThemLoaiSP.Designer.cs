﻿namespace QLCHVBDQ
{
    partial class fThemLoaiSP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemLoaiSP));
            this.label4 = new System.Windows.Forms.Label();
            this.textPTLN = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textTenLSP = new System.Windows.Forms.Label();
            this.textBoxMaLSP = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textMaDVT = new System.Windows.Forms.Label();
            this.textMaLSP = new System.Windows.Forms.Label();
            this.textThemLSP = new System.Windows.Forms.Label();
            this.textBoxTenLSP = new System.Windows.Forms.TextBox();
            this.numUDPTLN = new System.Windows.Forms.NumericUpDown();
            this.comboBoxMaDVT = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUDPTLN)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(832, 669);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(772, 2);
            this.label4.TabIndex = 35;
            // 
            // textPTLN
            // 
            this.textPTLN.AutoSize = true;
            this.textPTLN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPTLN.ForeColor = System.Drawing.Color.Black;
            this.textPTLN.Location = new System.Drawing.Point(828, 471);
            this.textPTLN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textPTLN.Name = "textPTLN";
            this.textPTLN.Size = new System.Drawing.Size(294, 32);
            this.textPTLN.TabIndex = 34;
            this.textPTLN.Text = "Phầm trăm lợi nhuận";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(832, 426);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(772, 2);
            this.label5.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(-3, 669);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(772, 2);
            this.label3.TabIndex = 31;
            // 
            // textTenLSP
            // 
            this.textTenLSP.AutoSize = true;
            this.textTenLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenLSP.ForeColor = System.Drawing.Color.Black;
            this.textTenLSP.Location = new System.Drawing.Point(828, 189);
            this.textTenLSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenLSP.Name = "textTenLSP";
            this.textTenLSP.Size = new System.Drawing.Size(264, 32);
            this.textTenLSP.TabIndex = 30;
            this.textTenLSP.Text = "Tên loại sản phẩm";
            this.textTenLSP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxMaLSP
            // 
            this.textBoxMaLSP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxMaLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaLSP.Location = new System.Drawing.Point(93, 292);
            this.textBoxMaLSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxMaLSP.Name = "textBoxMaLSP";
            this.textBoxMaLSP.Size = new System.Drawing.Size(364, 43);
            this.textBoxMaLSP.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(-3, 426);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(772, 2);
            this.label9.TabIndex = 29;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 151);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1612, 2);
            this.line1.TabIndex = 28;
            // 
            // textMaDVT
            // 
            this.textMaDVT.AutoSize = true;
            this.textMaDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaDVT.ForeColor = System.Drawing.Color.Black;
            this.textMaDVT.Location = new System.Drawing.Point(87, 471);
            this.textMaDVT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaDVT.Name = "textMaDVT";
            this.textMaDVT.Size = new System.Drawing.Size(204, 32);
            this.textMaDVT.TabIndex = 26;
            this.textMaDVT.Text = "Mã đơn vị tính";
            // 
            // textMaLSP
            // 
            this.textMaLSP.AutoSize = true;
            this.textMaLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMaLSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textMaLSP.Location = new System.Drawing.Point(87, 189);
            this.textMaLSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textMaLSP.Name = "textMaLSP";
            this.textMaLSP.Size = new System.Drawing.Size(262, 32);
            this.textMaLSP.TabIndex = 23;
            this.textMaLSP.Text = "Mã Loại sản phẩm";
            // 
            // textThemLSP
            // 
            this.textThemLSP.AutoSize = true;
            this.textThemLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemLSP.Location = new System.Drawing.Point(68, 62);
            this.textThemLSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemLSP.Name = "textThemLSP";
            this.textThemLSP.Size = new System.Drawing.Size(477, 55);
            this.textThemLSP.TabIndex = 21;
            this.textThemLSP.Text = "Thêm loại sản phẩm";
            // 
            // textBoxTenLSP
            // 
            this.textBoxTenLSP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenLSP.Location = new System.Drawing.Point(834, 292);
            this.textBoxTenLSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenLSP.Name = "textBoxTenLSP";
            this.textBoxTenLSP.Size = new System.Drawing.Size(449, 43);
            this.textBoxTenLSP.TabIndex = 36;
            // 
            // numUDPTLN
            // 
            this.numUDPTLN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUDPTLN.Location = new System.Drawing.Point(834, 554);
            this.numUDPTLN.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUDPTLN.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUDPTLN.Name = "numUDPTLN";
            this.numUDPTLN.Size = new System.Drawing.Size(309, 40);
            this.numUDPTLN.TabIndex = 80;
            // 
            // comboBoxMaDVT
            // 
            this.comboBoxMaDVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMaDVT.FormattingEnabled = true;
            this.comboBoxMaDVT.Location = new System.Drawing.Point(93, 548);
            this.comboBoxMaDVT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxMaDVT.Name = "comboBoxMaDVT";
            this.comboBoxMaDVT.Size = new System.Drawing.Size(362, 45);
            this.comboBoxMaDVT.TabIndex = 81;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1062, 743);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(434, 123);
            this.btnThem.TabIndex = 27;
            this.btnThem.Text = "Thêm loại sản phẩm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // fThemLoaiSP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 898);
            this.Controls.Add(this.comboBoxMaDVT);
            this.Controls.Add(this.numUDPTLN);
            this.Controls.Add(this.textBoxTenLSP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textPTLN);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textTenLSP);
            this.Controls.Add(this.textBoxMaLSP);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textMaDVT);
            this.Controls.Add(this.textMaLSP);
            this.Controls.Add(this.textThemLSP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemLoaiSP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm loại sản phẩm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fThemLoaiSP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUDPTLN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label textPTLN;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label textTenLSP;
        private System.Windows.Forms.TextBox textBoxMaLSP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textMaDVT;
        private System.Windows.Forms.Label textMaLSP;
        private System.Windows.Forms.Label textThemLSP;
        private System.Windows.Forms.TextBox textBoxTenLSP;
        private System.Windows.Forms.NumericUpDown numUDPTLN;
        private System.Windows.Forms.ComboBox comboBoxMaDVT;
    }
}