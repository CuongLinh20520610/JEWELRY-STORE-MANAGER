﻿namespace QLCHVBDQ
{
    partial class fThemCTPBH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fThemCTPBH));
            this.numUpDowwnSoLuong = new System.Windows.Forms.NumericUpDown();
            this.comboBoxTenSP = new System.Windows.Forms.ComboBox();
            this.textSoLuong = new System.Windows.Forms.Label();
            this.textTenSP = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxNgayLapPhieu = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxKhachHang = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxNewSoPhieu = new System.Windows.Forms.TextBox();
            this.line1 = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textThemCTPDV = new System.Windows.Forms.Label();
            this.btnThem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // numUpDowwnSoLuong
            // 
            this.numUpDowwnSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDowwnSoLuong.Location = new System.Drawing.Point(854, 603);
            this.numUpDowwnSoLuong.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.numUpDowwnSoLuong.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numUpDowwnSoLuong.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDowwnSoLuong.Name = "numUpDowwnSoLuong";
            this.numUpDowwnSoLuong.Size = new System.Drawing.Size(309, 40);
            this.numUpDowwnSoLuong.TabIndex = 117;
            this.numUpDowwnSoLuong.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // comboBoxTenSP
            // 
            this.comboBoxTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxTenSP.FormattingEnabled = true;
            this.comboBoxTenSP.Location = new System.Drawing.Point(118, 600);
            this.comboBoxTenSP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxTenSP.Name = "comboBoxTenSP";
            this.comboBoxTenSP.Size = new System.Drawing.Size(416, 45);
            this.comboBoxTenSP.TabIndex = 116;
            // 
            // textSoLuong
            // 
            this.textSoLuong.AutoSize = true;
            this.textSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoLuong.ForeColor = System.Drawing.Color.Black;
            this.textSoLuong.Location = new System.Drawing.Point(850, 558);
            this.textSoLuong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoLuong.Name = "textSoLuong";
            this.textSoLuong.Size = new System.Drawing.Size(135, 32);
            this.textSoLuong.TabIndex = 103;
            this.textSoLuong.Text = "Số lượng";
            // 
            // textTenSP
            // 
            this.textTenSP.AutoSize = true;
            this.textTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTenSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(179)))));
            this.textTenSP.Location = new System.Drawing.Point(112, 558);
            this.textTenSP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTenSP.Name = "textTenSP";
            this.textTenSP.Size = new System.Drawing.Size(206, 32);
            this.textTenSP.TabIndex = 101;
            this.textTenSP.Text = "Tên sản phẩm";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(-9, 535);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1679, 2);
            this.label3.TabIndex = 100;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(582, 458);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(585, 55);
            this.label13.TabIndex = 99;
            this.label13.Text = "Nhập thông tin sản phẩm";
            // 
            // textBoxNgayLapPhieu
            // 
            this.textBoxNgayLapPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNgayLapPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNgayLapPhieu.Location = new System.Drawing.Point(1104, 118);
            this.textBoxNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNgayLapPhieu.Name = "textBoxNgayLapPhieu";
            this.textBoxNgayLapPhieu.ReadOnly = true;
            this.textBoxNgayLapPhieu.Size = new System.Drawing.Size(455, 48);
            this.textBoxNgayLapPhieu.TabIndex = 96;
            this.textBoxNgayLapPhieu.TabStop = false;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BackColor = System.Drawing.Color.White;
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(1104, 234);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.ReadOnly = true;
            this.textBoxSDT.Size = new System.Drawing.Size(455, 48);
            this.textBoxSDT.TabIndex = 95;
            this.textBoxSDT.TabStop = false;
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.BackColor = System.Drawing.Color.White;
            this.textBoxTongTien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTongTien.Location = new System.Drawing.Point(298, 334);
            this.textBoxTongTien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.ReadOnly = true;
            this.textBoxTongTien.Size = new System.Drawing.Size(484, 48);
            this.textBoxTongTien.TabIndex = 89;
            this.textBoxTongTien.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(106, 343);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 32);
            this.label11.TabIndex = 90;
            this.label11.Text = "Tổng tiền";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(848, 243);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 32);
            this.label2.TabIndex = 88;
            this.label2.Text = "Số điện thoại";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxKhachHang
            // 
            this.textBoxKhachHang.BackColor = System.Drawing.Color.White;
            this.textBoxKhachHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxKhachHang.Location = new System.Drawing.Point(298, 234);
            this.textBoxKhachHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxKhachHang.Name = "textBoxKhachHang";
            this.textBoxKhachHang.ReadOnly = true;
            this.textBoxKhachHang.Size = new System.Drawing.Size(484, 48);
            this.textBoxKhachHang.TabIndex = 86;
            this.textBoxKhachHang.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(106, 243);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 32);
            this.label6.TabIndex = 87;
            this.label6.Text = "Khách hàng";
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(848, 128);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(204, 32);
            this.textNgapLapPhieu.TabIndex = 85;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxNewSoPhieu
            // 
            this.textBoxNewSoPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNewSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNewSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewSoPhieu.Location = new System.Drawing.Point(298, 118);
            this.textBoxNewSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNewSoPhieu.Name = "textBoxNewSoPhieu";
            this.textBoxNewSoPhieu.ReadOnly = true;
            this.textBoxNewSoPhieu.Size = new System.Drawing.Size(484, 48);
            this.textBoxNewSoPhieu.TabIndex = 82;
            this.textBoxNewSoPhieu.TabStop = false;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-6, 105);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1679, 2);
            this.line1.TabIndex = 84;
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.Black;
            this.textSoPhieu.Location = new System.Drawing.Point(106, 128);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(127, 32);
            this.textSoPhieu.TabIndex = 83;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textThemCTPDV
            // 
            this.textThemCTPDV.AutoSize = true;
            this.textThemCTPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textThemCTPDV.Location = new System.Drawing.Point(75, 29);
            this.textThemCTPDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textThemCTPDV.Name = "textThemCTPDV";
            this.textThemCTPDV.Size = new System.Drawing.Size(671, 55);
            this.textThemCTPDV.TabIndex = 81;
            this.textThemCTPDV.Text = "Thêm chi tiết phiếu bán hàng";
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1312, 734);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(38, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(248, 95);
            this.btnThem.TabIndex = 104;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // fThemCTPBH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1602, 943);
            this.Controls.Add(this.numUpDowwnSoLuong);
            this.Controls.Add(this.comboBoxTenSP);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.textSoLuong);
            this.Controls.Add(this.textTenSP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBoxNgayLapPhieu);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textBoxTongTien);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxKhachHang);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxNewSoPhieu);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textThemCTPDV);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fThemCTPBH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm chi tiết phiếu bán hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.numUpDowwnSoLuong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numUpDowwnSoLuong;
        private System.Windows.Forms.ComboBox comboBoxTenSP;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label textSoLuong;
        private System.Windows.Forms.Label textTenSP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxNgayLapPhieu;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.TextBox textBoxTongTien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKhachHang;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxNewSoPhieu;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textThemCTPDV;
    }
}