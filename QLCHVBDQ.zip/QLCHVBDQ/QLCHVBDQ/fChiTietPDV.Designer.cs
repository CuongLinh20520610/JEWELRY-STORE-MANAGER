﻿namespace QLCHVBDQ
{
    partial class fChiTietPDV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fChiTietPDV));
            this.label5 = new System.Windows.Forms.Label();
            this.textNgapLapPhieu = new System.Windows.Forms.Label();
            this.textBoxSoPhieu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.line1 = new System.Windows.Forms.Label();
            this.textSoPhieu = new System.Windows.Forms.Label();
            this.textChiTietPDV = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxKhachHang = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTraTruoc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxConLai = new System.Windows.Forms.TextBox();
            this.textBoxSDT = new System.Windows.Forms.TextBox();
            this.textBoxNgayLapPhieu = new System.Windows.Forms.TextBox();
            this.dtgvChiTietPDV = new System.Windows.Forms.DataGridView();
            this.textBoxTinhTrang = new System.Windows.Forms.TextBox();
            this.textTinhTrang = new System.Windows.Forms.Label();
            this.btnThem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvChiTietPDV)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(856, 215);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(797, 2);
            this.label5.TabIndex = 28;
            // 
            // textNgapLapPhieu
            // 
            this.textNgapLapPhieu.AutoSize = true;
            this.textNgapLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNgapLapPhieu.ForeColor = System.Drawing.Color.Black;
            this.textNgapLapPhieu.Location = new System.Drawing.Point(850, 126);
            this.textNgapLapPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textNgapLapPhieu.Name = "textNgapLapPhieu";
            this.textNgapLapPhieu.Size = new System.Drawing.Size(204, 32);
            this.textNgapLapPhieu.TabIndex = 26;
            this.textNgapLapPhieu.Text = "Ngày lập phiếu";
            this.textNgapLapPhieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxSoPhieu
            // 
            this.textBoxSoPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxSoPhieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSoPhieu.Location = new System.Drawing.Point(116, 168);
            this.textBoxSoPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSoPhieu.Name = "textBoxSoPhieu";
            this.textBoxSoPhieu.ReadOnly = true;
            this.textBoxSoPhieu.Size = new System.Drawing.Size(670, 41);
            this.textBoxSoPhieu.TabIndex = 19;
            this.textBoxSoPhieu.TabStop = false;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Location = new System.Drawing.Point(-2, 215);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(797, 2);
            this.label9.TabIndex = 25;
            // 
            // line1
            // 
            this.line1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.line1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.line1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.line1.Location = new System.Drawing.Point(-3, 103);
            this.line1.Margin = new System.Windows.Forms.Padding(0);
            this.line1.Name = "line1";
            this.line1.Size = new System.Drawing.Size(1679, 2);
            this.line1.TabIndex = 24;
            // 
            // textSoPhieu
            // 
            this.textSoPhieu.AutoSize = true;
            this.textSoPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSoPhieu.ForeColor = System.Drawing.Color.Black;
            this.textSoPhieu.Location = new System.Drawing.Point(110, 126);
            this.textSoPhieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textSoPhieu.Name = "textSoPhieu";
            this.textSoPhieu.Size = new System.Drawing.Size(127, 32);
            this.textSoPhieu.TabIndex = 20;
            this.textSoPhieu.Text = "Số phiếu";
            // 
            // textChiTietPDV
            // 
            this.textChiTietPDV.AutoSize = true;
            this.textChiTietPDV.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textChiTietPDV.Location = new System.Drawing.Point(78, 28);
            this.textChiTietPDV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textChiTietPDV.Name = "textChiTietPDV";
            this.textChiTietPDV.Size = new System.Drawing.Size(490, 55);
            this.textChiTietPDV.TabIndex = 18;
            this.textChiTietPDV.Text = "Chi tiết phiếu dịch vụ";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(856, 331);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(797, 2);
            this.label1.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(850, 243);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 32);
            this.label2.TabIndex = 33;
            this.label2.Text = "Số điện thoại";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxKhachHang
            // 
            this.textBoxKhachHang.BackColor = System.Drawing.Color.White;
            this.textBoxKhachHang.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxKhachHang.Location = new System.Drawing.Point(116, 285);
            this.textBoxKhachHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxKhachHang.Name = "textBoxKhachHang";
            this.textBoxKhachHang.ReadOnly = true;
            this.textBoxKhachHang.Size = new System.Drawing.Size(670, 41);
            this.textBoxKhachHang.TabIndex = 29;
            this.textBoxKhachHang.TabStop = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(-2, 331);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(797, 2);
            this.label4.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(110, 243);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 32);
            this.label6.TabIndex = 30;
            this.label6.Text = "Khách hàng";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Location = new System.Drawing.Point(846, 437);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(809, 2);
            this.label7.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(850, 352);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(223, 32);
            this.label8.TabIndex = 39;
            this.label8.Text = "Tổng tiền còn lại";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxTraTruoc
            // 
            this.textBoxTraTruoc.BackColor = System.Drawing.Color.White;
            this.textBoxTraTruoc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTraTruoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTraTruoc.Location = new System.Drawing.Point(116, 394);
            this.textBoxTraTruoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTraTruoc.Name = "textBoxTraTruoc";
            this.textBoxTraTruoc.ReadOnly = true;
            this.textBoxTraTruoc.Size = new System.Drawing.Size(670, 41);
            this.textBoxTraTruoc.TabIndex = 35;
            this.textBoxTraTruoc.TabStop = false;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Location = new System.Drawing.Point(-12, 437);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(797, 2);
            this.label10.TabIndex = 38;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(110, 352);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(243, 32);
            this.label11.TabIndex = 36;
            this.label11.Text = "Tổng tiền trả trước";
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.BackColor = System.Drawing.Color.White;
            this.textBoxTongTien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTongTien.Location = new System.Drawing.Point(116, 522);
            this.textBoxTongTien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.ReadOnly = true;
            this.textBoxTongTien.Size = new System.Drawing.Size(411, 41);
            this.textBoxTongTien.TabIndex = 41;
            this.textBoxTongTien.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(110, 475);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 32);
            this.label12.TabIndex = 42;
            this.label12.Text = "Tổng tiền";
            // 
            // textBoxConLai
            // 
            this.textBoxConLai.BackColor = System.Drawing.Color.White;
            this.textBoxConLai.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxConLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConLai.Location = new System.Drawing.Point(856, 394);
            this.textBoxConLai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxConLai.Name = "textBoxConLai";
            this.textBoxConLai.ReadOnly = true;
            this.textBoxConLai.Size = new System.Drawing.Size(759, 41);
            this.textBoxConLai.TabIndex = 43;
            this.textBoxConLai.TabStop = false;
            // 
            // textBoxSDT
            // 
            this.textBoxSDT.BackColor = System.Drawing.Color.White;
            this.textBoxSDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSDT.Location = new System.Drawing.Point(856, 285);
            this.textBoxSDT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSDT.Name = "textBoxSDT";
            this.textBoxSDT.ReadOnly = true;
            this.textBoxSDT.Size = new System.Drawing.Size(782, 41);
            this.textBoxSDT.TabIndex = 44;
            this.textBoxSDT.TabStop = false;
            // 
            // textBoxNgayLapPhieu
            // 
            this.textBoxNgayLapPhieu.BackColor = System.Drawing.Color.White;
            this.textBoxNgayLapPhieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNgayLapPhieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNgayLapPhieu.Location = new System.Drawing.Point(856, 168);
            this.textBoxNgayLapPhieu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNgayLapPhieu.Name = "textBoxNgayLapPhieu";
            this.textBoxNgayLapPhieu.ReadOnly = true;
            this.textBoxNgayLapPhieu.Size = new System.Drawing.Size(782, 41);
            this.textBoxNgayLapPhieu.TabIndex = 45;
            this.textBoxNgayLapPhieu.TabStop = false;
            // 
            // dtgvChiTietPDV
            // 
            this.dtgvChiTietPDV.AllowUserToAddRows = false;
            this.dtgvChiTietPDV.AllowUserToDeleteRows = false;
            this.dtgvChiTietPDV.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgvChiTietPDV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvChiTietPDV.BackgroundColor = System.Drawing.Color.White;
            this.dtgvChiTietPDV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvChiTietPDV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvChiTietPDV.ColumnHeadersHeight = 36;
            this.dtgvChiTietPDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgvChiTietPDV.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvChiTietPDV.Location = new System.Drawing.Point(18, 605);
            this.dtgvChiTietPDV.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dtgvChiTietPDV.Name = "dtgvChiTietPDV";
            this.dtgvChiTietPDV.ReadOnly = true;
            this.dtgvChiTietPDV.RowHeadersVisible = false;
            this.dtgvChiTietPDV.RowHeadersWidth = 62;
            this.dtgvChiTietPDV.RowTemplate.Height = 36;
            this.dtgvChiTietPDV.Size = new System.Drawing.Size(1598, 683);
            this.dtgvChiTietPDV.TabIndex = 46;
            this.dtgvChiTietPDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvChiTietPDV_CellClick);
            // 
            // textBoxTinhTrang
            // 
            this.textBoxTinhTrang.BackColor = System.Drawing.Color.White;
            this.textBoxTinhTrang.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTinhTrang.Location = new System.Drawing.Point(856, 522);
            this.textBoxTinhTrang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTinhTrang.Name = "textBoxTinhTrang";
            this.textBoxTinhTrang.ReadOnly = true;
            this.textBoxTinhTrang.Size = new System.Drawing.Size(414, 41);
            this.textBoxTinhTrang.TabIndex = 48;
            this.textBoxTinhTrang.TabStop = false;
            // 
            // textTinhTrang
            // 
            this.textTinhTrang.AutoSize = true;
            this.textTinhTrang.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTinhTrang.ForeColor = System.Drawing.Color.Black;
            this.textTinhTrang.Location = new System.Drawing.Point(850, 475);
            this.textTinhTrang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textTinhTrang.Name = "textTinhTrang";
            this.textTinhTrang.Size = new System.Drawing.Size(142, 32);
            this.textTinhTrang.TabIndex = 47;
            this.textTinhTrang.Text = "Tình trạng";
            this.textTinhTrang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.Image = ((System.Drawing.Image)(resources.GetObject("btnThem.Image")));
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(1410, 522);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Padding = new System.Windows.Forms.Padding(22, 8, 0, 8);
            this.btnThem.Size = new System.Drawing.Size(206, 74);
            this.btnThem.TabIndex = 49;
            this.btnThem.Text = "add";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // fChiTietPDV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1656, 1050);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.textBoxTinhTrang);
            this.Controls.Add(this.textTinhTrang);
            this.Controls.Add(this.dtgvChiTietPDV);
            this.Controls.Add(this.textBoxNgayLapPhieu);
            this.Controls.Add(this.textBoxSDT);
            this.Controls.Add(this.textBoxConLai);
            this.Controls.Add(this.textBoxTongTien);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxTraTruoc);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxKhachHang);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textNgapLapPhieu);
            this.Controls.Add(this.textBoxSoPhieu);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.line1);
            this.Controls.Add(this.textSoPhieu);
            this.Controls.Add(this.textChiTietPDV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fChiTietPDV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chi tiết phiếu dịch vụ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dtgvChiTietPDV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label textNgapLapPhieu;
        private System.Windows.Forms.TextBox textBoxSoPhieu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label line1;
        private System.Windows.Forms.Label textSoPhieu;
        private System.Windows.Forms.Label textChiTietPDV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKhachHang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxTraTruoc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxTongTien;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxConLai;
        private System.Windows.Forms.TextBox textBoxSDT;
        private System.Windows.Forms.TextBox textBoxNgayLapPhieu;
        private System.Windows.Forms.DataGridView dtgvChiTietPDV;
        private System.Windows.Forms.TextBox textBoxTinhTrang;
        private System.Windows.Forms.Label textTinhTrang;
        private System.Windows.Forms.Button btnThem;
    }
}