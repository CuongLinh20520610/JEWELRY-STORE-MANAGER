﻿namespace QLCHVBDQ
{
    partial class fBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.DashboardTrangChu = new System.Windows.Forms.Panel();
            this.btnBaoCao = new System.Windows.Forms.Button();
            this.btnNCC = new System.Windows.Forms.Button();
            this.btnBanHang = new System.Windows.Forms.Button();
            this.btnMuaHang = new System.Windows.Forms.Button();
            this.btnLoaiDichVu = new System.Windows.Forms.Button();
            this.btnDichVu = new System.Windows.Forms.Button();
            this.btnLoaiSanPham = new System.Windows.Forms.Button();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.btnTrangChu = new System.Windows.Forms.Button();
            this.textTimKiem = new System.Windows.Forms.TextBox();
            this.TrangChu = new System.Windows.Forms.Panel();
            this.panelTTTK = new System.Windows.Forms.Panel();
            this.buttonDangXuat = new System.Windows.Forms.Button();
            this.btnThongTinTaiKhoan = new System.Windows.Forms.Button();
            this.panelMoreOption = new System.Windows.Forms.Panel();
            this.btnChiTiet = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.panelUserName = new System.Windows.Forms.Panel();
            this.textUserName = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.dtgvPBH = new System.Windows.Forms.DataGridView();
            this.btndetetes = new System.Windows.Forms.PictureBox();
            this.btnThemPBH = new System.Windows.Forms.Button();
            this.textDsPBH = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DashboardTrangChu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.TrangChu.SuspendLayout();
            this.panelTTTK.SuspendLayout();
            this.panelMoreOption.SuspendLayout();
            this.panelUserName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPBH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btndetetes)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // DashboardTrangChu
            // 
            this.DashboardTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.DashboardTrangChu.Controls.Add(this.btnBaoCao);
            this.DashboardTrangChu.Controls.Add(this.btnNCC);
            this.DashboardTrangChu.Controls.Add(this.btnBanHang);
            this.DashboardTrangChu.Controls.Add(this.btnMuaHang);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiDichVu);
            this.DashboardTrangChu.Controls.Add(this.btnDichVu);
            this.DashboardTrangChu.Controls.Add(this.btnLoaiSanPham);
            this.DashboardTrangChu.Controls.Add(this.btnSanPham);
            this.DashboardTrangChu.Controls.Add(this.picBoxLogo);
            this.DashboardTrangChu.Controls.Add(this.btnTrangChu);
            this.DashboardTrangChu.Location = new System.Drawing.Point(0, 0);
            this.DashboardTrangChu.Name = "DashboardTrangChu";
            this.DashboardTrangChu.Size = new System.Drawing.Size(127, 836);
            this.DashboardTrangChu.TabIndex = 0;
            // 
            // btnBaoCao
            // 
            this.btnBaoCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBaoCao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBaoCao.FlatAppearance.BorderSize = 0;
            this.btnBaoCao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBaoCao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaoCao.ForeColor = System.Drawing.Color.White;
            this.btnBaoCao.Location = new System.Drawing.Point(0, 481);
            this.btnBaoCao.Margin = new System.Windows.Forms.Padding(0);
            this.btnBaoCao.Name = "btnBaoCao";
            this.btnBaoCao.Size = new System.Drawing.Size(127, 44);
            this.btnBaoCao.TabIndex = 9;
            this.btnBaoCao.Text = "Báo cáo";
            this.btnBaoCao.UseVisualStyleBackColor = false;
            this.btnBaoCao.Click += new System.EventHandler(this.btnBaoCao_Click);
            // 
            // btnNCC
            // 
            this.btnNCC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnNCC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNCC.FlatAppearance.BorderSize = 0;
            this.btnNCC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNCC.ForeColor = System.Drawing.Color.White;
            this.btnNCC.Location = new System.Drawing.Point(0, 437);
            this.btnNCC.Name = "btnNCC";
            this.btnNCC.Size = new System.Drawing.Size(127, 44);
            this.btnNCC.TabIndex = 8;
            this.btnNCC.Text = "Nhà cung cấp";
            this.btnNCC.UseVisualStyleBackColor = false;
            this.btnNCC.Click += new System.EventHandler(this.btnNCC_Click);
            // 
            // btnBanHang
            // 
            this.btnBanHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnBanHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBanHang.FlatAppearance.BorderSize = 0;
            this.btnBanHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBanHang.ForeColor = System.Drawing.Color.White;
            this.btnBanHang.Location = new System.Drawing.Point(0, 393);
            this.btnBanHang.Name = "btnBanHang";
            this.btnBanHang.Size = new System.Drawing.Size(127, 44);
            this.btnBanHang.TabIndex = 7;
            this.btnBanHang.Text = "Bán hàng";
            this.btnBanHang.UseVisualStyleBackColor = false;
            // 
            // btnMuaHang
            // 
            this.btnMuaHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnMuaHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMuaHang.FlatAppearance.BorderSize = 0;
            this.btnMuaHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMuaHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuaHang.ForeColor = System.Drawing.Color.White;
            this.btnMuaHang.Location = new System.Drawing.Point(0, 349);
            this.btnMuaHang.Name = "btnMuaHang";
            this.btnMuaHang.Size = new System.Drawing.Size(127, 44);
            this.btnMuaHang.TabIndex = 6;
            this.btnMuaHang.Text = "Mua Hàng";
            this.btnMuaHang.UseVisualStyleBackColor = false;
            this.btnMuaHang.Click += new System.EventHandler(this.btnMuaHang_Click);
            // 
            // btnLoaiDichVu
            // 
            this.btnLoaiDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiDichVu.FlatAppearance.BorderSize = 0;
            this.btnLoaiDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiDichVu.ForeColor = System.Drawing.Color.White;
            this.btnLoaiDichVu.Location = new System.Drawing.Point(0, 305);
            this.btnLoaiDichVu.Name = "btnLoaiDichVu";
            this.btnLoaiDichVu.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiDichVu.TabIndex = 5;
            this.btnLoaiDichVu.Text = "Loại dịch vụ";
            this.btnLoaiDichVu.UseVisualStyleBackColor = false;
            this.btnLoaiDichVu.Click += new System.EventHandler(this.btnLoaiDichVu_Click);
            // 
            // btnDichVu
            // 
            this.btnDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnDichVu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDichVu.FlatAppearance.BorderSize = 0;
            this.btnDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDichVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDichVu.ForeColor = System.Drawing.Color.White;
            this.btnDichVu.Location = new System.Drawing.Point(0, 261);
            this.btnDichVu.Name = "btnDichVu";
            this.btnDichVu.Size = new System.Drawing.Size(127, 44);
            this.btnDichVu.TabIndex = 4;
            this.btnDichVu.Text = "Dịch vụ";
            this.btnDichVu.UseVisualStyleBackColor = false;
            this.btnDichVu.Click += new System.EventHandler(this.btnDichVu_Click);
            // 
            // btnLoaiSanPham
            // 
            this.btnLoaiSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnLoaiSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoaiSanPham.FlatAppearance.BorderSize = 0;
            this.btnLoaiSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoaiSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoaiSanPham.ForeColor = System.Drawing.Color.White;
            this.btnLoaiSanPham.Location = new System.Drawing.Point(0, 217);
            this.btnLoaiSanPham.Name = "btnLoaiSanPham";
            this.btnLoaiSanPham.Size = new System.Drawing.Size(127, 44);
            this.btnLoaiSanPham.TabIndex = 3;
            this.btnLoaiSanPham.Text = "Loại sản phẩm";
            this.btnLoaiSanPham.UseVisualStyleBackColor = false;
            this.btnLoaiSanPham.Click += new System.EventHandler(this.btnLoaiSanPham_Click);
            // 
            // btnSanPham
            // 
            this.btnSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSanPham.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSanPham.FlatAppearance.BorderSize = 0;
            this.btnSanPham.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.ForeColor = System.Drawing.Color.White;
            this.btnSanPham.Location = new System.Drawing.Point(0, 173);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(127, 44);
            this.btnSanPham.TabIndex = 2;
            this.btnSanPham.Text = "Sản Phẩm";
            this.btnSanPham.UseVisualStyleBackColor = false;
            this.btnSanPham.Click += new System.EventHandler(this.btnSanPham_Click);
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.picBoxLogo.Image = global::QLCHVBDQ.Properties.Resources.madrid;
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Padding = new System.Windows.Forms.Padding(5, 7, 5, 5);
            this.picBoxLogo.Size = new System.Drawing.Size(127, 129);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 1;
            this.picBoxLogo.TabStop = false;
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTrangChu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTrangChu.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btnTrangChu.FlatAppearance.BorderSize = 0;
            this.btnTrangChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangChu.ForeColor = System.Drawing.Color.White;
            this.btnTrangChu.Location = new System.Drawing.Point(0, 129);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(127, 44);
            this.btnTrangChu.TabIndex = 0;
            this.btnTrangChu.Text = "Trang chủ";
            this.btnTrangChu.UseCompatibleTextRendering = true;
            this.btnTrangChu.UseVisualStyleBackColor = false;
            this.btnTrangChu.Click += new System.EventHandler(this.btnTrangChu_Click);
            // 
            // textTimKiem
            // 
            this.textTimKiem.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTimKiem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTimKiem.Location = new System.Drawing.Point(46, 12);
            this.textTimKiem.Name = "textTimKiem";
            this.textTimKiem.Size = new System.Drawing.Size(407, 28);
            this.textTimKiem.TabIndex = 6;
            this.textTimKiem.Text = "Tìm kiếm";
            // 
            // TrangChu
            // 
            this.TrangChu.AutoScroll = true;
            this.TrangChu.BackColor = System.Drawing.Color.White;
            this.TrangChu.Controls.Add(this.panelTTTK);
            this.TrangChu.Controls.Add(this.panelMoreOption);
            this.TrangChu.Controls.Add(this.panelUserName);
            this.TrangChu.Controls.Add(this.dtgvPBH);
            this.TrangChu.Controls.Add(this.btndetetes);
            this.TrangChu.Controls.Add(this.btnThemPBH);
            this.TrangChu.Controls.Add(this.textDsPBH);
            this.TrangChu.Controls.Add(this.panel1);
            this.TrangChu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangChu.Location = new System.Drawing.Point(127, 0);
            this.TrangChu.Margin = new System.Windows.Forms.Padding(0);
            this.TrangChu.Name = "TrangChu";
            this.TrangChu.Size = new System.Drawing.Size(1147, 836);
            this.TrangChu.TabIndex = 1;
            // 
            // panelTTTK
            // 
            this.panelTTTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panelTTTK.Controls.Add(this.buttonDangXuat);
            this.panelTTTK.Controls.Add(this.btnThongTinTaiKhoan);
            this.panelTTTK.Location = new System.Drawing.Point(722, 29);
            this.panelTTTK.Name = "panelTTTK";
            this.panelTTTK.Size = new System.Drawing.Size(140, 74);
            this.panelTTTK.TabIndex = 9;
            this.panelTTTK.Visible = false;
            // 
            // buttonDangXuat
            // 
            this.buttonDangXuat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonDangXuat.FlatAppearance.BorderSize = 0;
            this.buttonDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDangXuat.Location = new System.Drawing.Point(2, 34);
            this.buttonDangXuat.Margin = new System.Windows.Forms.Padding(1);
            this.buttonDangXuat.Name = "buttonDangXuat";
            this.buttonDangXuat.Size = new System.Drawing.Size(137, 32);
            this.buttonDangXuat.TabIndex = 3;
            this.buttonDangXuat.Text = "Đăng xuất";
            this.buttonDangXuat.UseVisualStyleBackColor = false;
            this.buttonDangXuat.Click += new System.EventHandler(this.buttonDangXuat_Click);
            // 
            // btnThongTinTaiKhoan
            // 
            this.btnThongTinTaiKhoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThongTinTaiKhoan.FlatAppearance.BorderSize = 0;
            this.btnThongTinTaiKhoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThongTinTaiKhoan.Location = new System.Drawing.Point(1, 0);
            this.btnThongTinTaiKhoan.Margin = new System.Windows.Forms.Padding(1);
            this.btnThongTinTaiKhoan.Name = "btnThongTinTaiKhoan";
            this.btnThongTinTaiKhoan.Size = new System.Drawing.Size(141, 32);
            this.btnThongTinTaiKhoan.TabIndex = 2;
            this.btnThongTinTaiKhoan.Text = "Thông tin tài khoản";
            this.btnThongTinTaiKhoan.UseVisualStyleBackColor = false;
            this.btnThongTinTaiKhoan.Click += new System.EventHandler(this.btnThongTinTaiKhoan_Click);
            // 
            // panelMoreOption
            // 
            this.panelMoreOption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.panelMoreOption.Controls.Add(this.btnChiTiet);
            this.panelMoreOption.Controls.Add(this.btnXoa);
            this.panelMoreOption.Controls.Add(this.btnThem);
            this.panelMoreOption.Location = new System.Drawing.Point(976, 720);
            this.panelMoreOption.Name = "panelMoreOption";
            this.panelMoreOption.Size = new System.Drawing.Size(86, 104);
            this.panelMoreOption.TabIndex = 14;
            this.panelMoreOption.Visible = false;
            // 
            // btnChiTiet
            // 
            this.btnChiTiet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnChiTiet.FlatAppearance.BorderSize = 0;
            this.btnChiTiet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChiTiet.Location = new System.Drawing.Point(1, 65);
            this.btnChiTiet.Margin = new System.Windows.Forms.Padding(1);
            this.btnChiTiet.Name = "btnChiTiet";
            this.btnChiTiet.Size = new System.Drawing.Size(86, 29);
            this.btnChiTiet.TabIndex = 3;
            this.btnChiTiet.Text = "Chi tiết";
            this.btnChiTiet.UseVisualStyleBackColor = false;
            this.btnChiTiet.Click += new System.EventHandler(this.btnChiTiet_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnXoa.FlatAppearance.BorderSize = 0;
            this.btnXoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoa.Location = new System.Drawing.Point(-1, 34);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(1);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(86, 29);
            this.btnXoa.TabIndex = 1;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(169)))), ((int)(((byte)(255)))));
            this.btnThem.FlatAppearance.BorderSize = 0;
            this.btnThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem.Location = new System.Drawing.Point(0, 3);
            this.btnThem.Margin = new System.Windows.Forms.Padding(1);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(86, 29);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // panelUserName
            // 
            this.panelUserName.Controls.Add(this.textUserName);
            this.panelUserName.Controls.Add(this.pictureBox3);
            this.panelUserName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelUserName.Location = new System.Drawing.Point(868, 29);
            this.panelUserName.Name = "panelUserName";
            this.panelUserName.Size = new System.Drawing.Size(255, 36);
            this.panelUserName.TabIndex = 13;
            // 
            // textUserName
            // 
            this.textUserName.AutoSize = true;
            this.textUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textUserName.Location = new System.Drawing.Point(27, 4);
            this.textUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(176, 29);
            this.textUserName.TabIndex = 6;
            this.textUserName.Text = "Nguyen Van A";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::QLCHVBDQ.Properties.Resources.UserCircle;
            this.pictureBox3.Location = new System.Drawing.Point(0, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 24);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // dtgvPBH
            // 
            this.dtgvPBH.AllowUserToAddRows = false;
            this.dtgvPBH.AllowUserToDeleteRows = false;
            this.dtgvPBH.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvPBH.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvPBH.BackgroundColor = System.Drawing.Color.White;
            this.dtgvPBH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvPBH.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvPBH.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvPBH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtgvPBH.Location = new System.Drawing.Point(20, 195);
            this.dtgvPBH.Name = "dtgvPBH";
            this.dtgvPBH.ReadOnly = true;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvPBH.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvPBH.RowHeadersWidth = 62;
            this.dtgvPBH.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtgvPBH.RowTemplate.Height = 36;
            this.dtgvPBH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvPBH.ShowRowErrors = false;
            this.dtgvPBH.Size = new System.Drawing.Size(1103, 619);
            this.dtgvPBH.TabIndex = 12;
            this.dtgvPBH.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPBH_CellClick);
            this.dtgvPBH.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgvPBH_CellMouseMove);
            // 
            // btndetetes
            // 
            this.btndetetes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndetetes.Image = global::QLCHVBDQ.Properties.Resources.Trash_Full;
            this.btndetetes.Location = new System.Drawing.Point(1078, 130);
            this.btndetetes.Name = "btndetetes";
            this.btndetetes.Size = new System.Drawing.Size(40, 40);
            this.btndetetes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btndetetes.TabIndex = 11;
            this.btndetetes.TabStop = false;
            this.btndetetes.Click += new System.EventHandler(this.btnDeletes_Click);
            // 
            // btnThemPBH
            // 
            this.btnThemPBH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnThemPBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnThemPBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThemPBH.FlatAppearance.BorderSize = 0;
            this.btnThemPBH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemPBH.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPBH.ForeColor = System.Drawing.Color.White;
            this.btnThemPBH.Image = global::QLCHVBDQ.Properties.Resources.Icon_plus;
            this.btnThemPBH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemPBH.Location = new System.Drawing.Point(713, 113);
            this.btnThemPBH.Name = "btnThemPBH";
            this.btnThemPBH.Padding = new System.Windows.Forms.Padding(20, 5, 5, 5);
            this.btnThemPBH.Size = new System.Drawing.Size(349, 62);
            this.btnThemPBH.TabIndex = 10;
            this.btnThemPBH.Text = "Thêm phiếu bán hàng";
            this.btnThemPBH.UseVisualStyleBackColor = false;
            this.btnThemPBH.Click += new System.EventHandler(this.btnThemPBH_Click);
            // 
            // textDsPBH
            // 
            this.textDsPBH.AutoSize = true;
            this.textDsPBH.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDsPBH.Location = new System.Drawing.Point(14, 114);
            this.textDsPBH.Name = "textDsPBH";
            this.textDsPBH.Size = new System.Drawing.Size(600, 53);
            this.textDsPBH.TabIndex = 9;
            this.textDsPBH.Text = "Danh sách phiếu bán hàng";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.textTimKiem);
            this.panel1.Location = new System.Drawing.Point(20, 44);
            this.panel1.Margin = new System.Windows.Forms.Padding(10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 44);
            this.panel1.TabIndex = 8;
            this.panel1.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLCHVBDQ.Properties.Resources.Search_Magnifying_Glass;
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 24);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // fBanHang
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1278, 819);
            this.Controls.Add(this.TrangChu);
            this.Controls.Add(this.DashboardTrangChu);
            this.MaximumSize = new System.Drawing.Size(1300, 875);
            this.Name = "fBanHang";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bán hàng";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.DashboardTrangChu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.TrangChu.ResumeLayout(false);
            this.TrangChu.PerformLayout();
            this.panelTTTK.ResumeLayout(false);
            this.panelMoreOption.ResumeLayout(false);
            this.panelUserName.ResumeLayout(false);
            this.panelUserName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPBH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btndetetes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DashboardTrangChu;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Button btnTrangChu;
        private System.Windows.Forms.Button btnBaoCao;
        private System.Windows.Forms.Button btnNCC;
        private System.Windows.Forms.Button btnBanHang;
        private System.Windows.Forms.Button btnMuaHang;
        private System.Windows.Forms.Button btnLoaiDichVu;
        private System.Windows.Forms.Button btnDichVu;
        private System.Windows.Forms.Button btnLoaiSanPham;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.TextBox textTimKiem;
        private System.Windows.Forms.Panel TrangChu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label textDsPBH;
        private System.Windows.Forms.Button btnThemPBH;
        private System.Windows.Forms.PictureBox btndetetes;
        private System.Windows.Forms.DataGridView dtgvPBH;
        private System.Windows.Forms.Panel panelUserName;
        private System.Windows.Forms.Label textUserName;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panelMoreOption;
        private System.Windows.Forms.Button btnChiTiet;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Panel panelTTTK;
        private System.Windows.Forms.Button buttonDangXuat;
        private System.Windows.Forms.Button btnThongTinTaiKhoan;
    }
}